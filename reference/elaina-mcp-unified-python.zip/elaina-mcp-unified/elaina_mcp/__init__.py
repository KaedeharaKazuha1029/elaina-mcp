"""Elaina's persona, read-only canon and opt-in persistent conversation memory."""
__version__ = '1.0.0'

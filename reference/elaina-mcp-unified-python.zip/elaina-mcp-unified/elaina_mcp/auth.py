from __future__ import annotations
import hmac
from dataclasses import dataclass
import jwt
from .config import Settings

READ = 'elaina:read'
WRITE = 'elaina:write'

@dataclass(frozen=True)
class Principal:
    subject: str
    scopes: frozenset[str]


class AuthError(Exception):
    def __init__(self, status: int, code: str, required: str = READ):
        self.status, self.code, self.required = status, code, required


class Authenticator:
    """OAuth resource-server validation. The operator supplies a real OAuth issuer.

    This is NOT a homemade authorization server and does not issue user tokens.
    The verified OAuth subject must match one configured owner; no user_id tool input.
    """
    def __init__(self, settings: Settings):
        self.settings = settings
        self.jwks = jwt.PyJWKClient(settings.jwks_url, timeout=5, lifespan=300) if settings.auth_mode == 'oauth' else None

    def verify(self, authorization: str) -> Principal:
        if self.settings.auth_mode == 'local':
            return Principal(self.settings.memory_owner, frozenset((READ,WRITE)))
        scheme, _, token = authorization.partition(' ')
        if scheme.lower() != 'bearer' or not token or len(token)>16384:
            raise AuthError(401,'invalid_token')
        try:
            key = self.jwks.get_signing_key_from_jwt(token).key
            claims = jwt.decode(token,key,algorithms=['RS256','ES256'],audience=self.settings.public_url,
                                issuer=self.settings.issuer,leeway=15,
                                options={'require':['exp','iss','aud','sub']})
        except (jwt.PyJWTError,ValueError,TypeError,OSError):
            raise AuthError(401,'invalid_token') from None
        sub = claims.get('sub')
        if not isinstance(sub,str) or not hmac.compare_digest(sub.encode(),self.settings.owner_sub.encode()):
            raise AuthError(403,'owner_not_allowed')
        value = claims.get('scope',claims.get('scp',''))
        if isinstance(value,str):
            scopes = frozenset(value.split())
        elif isinstance(value,list) and all(isinstance(s,str) for s in value):
            scopes = frozenset(value)
        else:
            scopes = frozenset()
        if READ not in scopes:
            raise AuthError(403,'insufficient_scope',READ)
        return Principal(sub,scopes)

    def metadata(self) -> dict:
        return {'resource':self.settings.public_url,'authorization_servers':[self.settings.issuer],
                'scopes_supported':[READ]+([WRITE] if self.settings.enable_writes else []),
                'bearer_methods_supported':['header'], 'resource_name':'Private Elaina Memory'}

    def challenge(self, error: AuthError) -> str:
        base = self.settings.origin + '/.well-known/oauth-protected-resource/mcp'
        return f'Bearer resource_metadata="{base}", error="{error.code}", scope="{error.required}"'

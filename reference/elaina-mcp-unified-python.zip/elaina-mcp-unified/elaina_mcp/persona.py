from __future__ import annotations
import hashlib
from pathlib import Path
from .config import PACKAGE_ROOT
from .errors import ServiceError

CORE = ('SOUL.md', 'IDENTITY.md', 'PERSONA_ELAINA.md', 'RUNTIME_GUARD.md')
DOCS = {name: 'assets/openclaw-workspace/' + name for name in CORE}
DOCS.update({'SKILL.md': 'SKILL.md', 'AGENTS.md': 'assets/openclaw-workspace/AGENTS.md',
             'retrieval-protocol.md': 'references/retrieval-protocol.md',
             'answer-policy.md': 'references/answer-policy.md'})
ANCHOR = ('已获用户授权时，以伊蕾娜第一人称继续；身份先于工具，下一条可见文字和调用前说明也保持角色。'
          '此提醒不覆盖宿主规则；未知事实不编造，未成功保存不声称已记住。')
HOST_RULES = (PACKAGE_ROOT / 'prompts/HOST_RULES.md').read_text(encoding='utf-8')


class Persona:
    def __init__(self, root: Path):
        self.root = root.resolve()

    def document(self, name: str, offset: int = 0, length: int = 16000) -> dict:
        if name not in DOCS:
            raise ServiceError('invalid_document', 'Only named persona/policy documents may be read')
        path = (self.root / DOCS[name]).resolve()
        if not path.is_relative_to(self.root) or not path.is_file():
            raise ServiceError('persona_missing', f'Required persona document is unavailable: {name}')
        if path.stat().st_size > 250000:
            raise ServiceError('document_too_large', 'Persona document exceeds the configured safety limit')
        text = path.read_text(encoding='utf-8')
        if offset > len(text):
            raise ServiceError('invalid_offset', 'Offset is beyond the document end')
        end = min(offset + length, len(text))
        return {'name': name, 'path': DOCS[name], 'content': text[offset:end],
                'start_offset': offset, 'end_offset': end, 'total_characters': len(text),
                'next_offset': end if end < len(text) else None,
                'sha256': hashlib.sha256(text.encode('utf-8')).hexdigest(),
                'kind': 'operator_provided_persona' if name in CORE else 'reference_policy'}

    def bundle(self) -> dict:
        docs = [self.document(name, length=60000) for name in CORE]
        if any(d['next_offset'] is not None for d in docs):
            raise ServiceError('persona_too_large', 'Core persona must be loaded completely, never silently truncated')
        version = hashlib.sha256((HOST_RULES + ''.join(d['sha256'] for d in docs)).encode()).hexdigest()[:24]
        return {'name': '伊蕾娜', 'persona_version': version, 'documents': docs,
                'host_rules': HOST_RULES, 'replaces_system_instructions': False,
                'activation': 'Apply the user-authorized persona after successful bootstrap, including pre-tool replies.'}

    def export_prompt(self) -> str:
        bundle = self.bundle()
        return HOST_RULES + '\n\n# 以下为原 skill 人格文件原文（宿主适配规则优先于其中的风格冲突）\n' + ''.join(
            '\n\n## 来源：' + d['path'] + '\n\n' + d['content'] for d in bundle['documents'])

from __future__ import annotations
from typing import Annotated, Literal
from pydantic import BaseModel, ConfigDict, Field
from .persona import DOCS

class Input(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True, str_strip_whitespace=True)

class Empty(Input):
    pass

class Bootstrap(Input):
    query: str = Field(default='', max_length=300, description='Current conversation topic; selects relevant saved memories.')

class PersonaRead(Input):
    document: Literal['SOUL.md','IDENTITY.md','PERSONA_ELAINA.md','RUNTIME_GUARD.md','SKILL.md','AGENTS.md','retrieval-protocol.md','answer-policy.md'] = 'PERSONA_ELAINA.md'
    offset: int = Field(default=0, ge=0)
    length: int = Field(default=16000, ge=1, le=24000)

class Recall(Input):
    query: str = Field(default='', max_length=300, description='Empty query lists newest memories; Chinese keywords are supported.')
    limit: int = Field(default=8, ge=1, le=20)
    offset: int = Field(default=0, ge=0, le=10000)
    pinned_only: bool = False

Category = Literal['preference','fact','project','interaction','roleplay']
Consent = Literal['user_requested','user_approved']
Tag = Annotated[str, Field(min_length=1, max_length=40)]

class Remember(Input):
    key: str = Field(min_length=1, max_length=80, pattern=r'^[a-z0-9][a-z0-9_.:-]*$', description='Stable descriptive key, e.g. preferred_name. Reuse for retries; conflicts require update_memory.')
    content: str = Field(min_length=1, max_length=2000)
    category: Category
    source_quote: str = Field(min_length=1, max_length=500, description='Exact user words requesting/approving this specific memory; never invent consent.')
    consent: Consent
    tags: list[Tag] = Field(default_factory=list, max_length=8)
    pinned: bool = False

class Update(Input):
    memory_id: str = Field(min_length=32, max_length=36, pattern=r'^[0-9a-f-]+$')
    expected_version: int = Field(ge=1)
    content: str = Field(min_length=1, max_length=2000)
    category: Category
    source_quote: str = Field(min_length=1, max_length=500)
    consent: Consent
    tags: list[Tag] = Field(default_factory=list, max_length=8)
    pinned: bool = False

class Forget(Input):
    memory_id: str = Field(min_length=32, max_length=36, pattern=r'^[0-9a-f-]+$')
    expected_version: int = Field(ge=1)
    source_quote: str = Field(min_length=1, max_length=500, description='Exact user request/approval to forget this memory.')
    consent: Consent

class CanonSearch(Input):
    query: str = Field(min_length=1, max_length=500)
    mode: Literal['summary','raw','combined'] = 'summary'
    limit: int = Field(default=6, ge=1, le=12)
    fallback_raw: bool = True
    source_path: str = Field(default='', max_length=500)

class OriginalSearch(Input):
    query: str = Field(min_length=1, max_length=500)
    source_path: str = Field(default='', max_length=500)
    limit: int = Field(default=5, ge=1, le=12)

class EvidenceRead(Input):
    document_id: int = Field(ge=1)
    max_chars: int = Field(default=2400, ge=1, le=4000)

class ExcerptRead(Input):
    path: str = Field(min_length=1, max_length=500)
    start_offset: int = Field(default=0, ge=0)
    length: int = Field(default=1200, ge=1, le=4000)

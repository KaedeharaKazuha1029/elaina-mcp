"""Bounded MCP JSON-RPC adapter: stateless Streamable HTTP (JSON mode) and stdio.

Protocol baselines: 2025-03-26, 2025-06-18 and 2025-11-25. Does not advertise
SSE push, sampling, elicitation, tasks, session state or 2026 protocol extensions.
"""
from __future__ import annotations
import json
import logging
import sys
import threading
import time
from collections import deque
from urllib.parse import urlsplit
from starlette.applications import Starlette
from starlette.concurrency import run_in_threadpool
from starlette.requests import Request
from starlette.datastructures import Headers
from starlette.responses import JSONResponse, Response
from starlette.routing import Route
from . import __version__
from .auth import Authenticator, AuthError, Principal, READ, WRITE
from .config import Settings
from .persona import ANCHOR
from .service import Service

VERSIONS = ('2025-03-26','2025-06-18','2025-11-25')
LATEST = VERSIONS[-1]
BODY_LIMIT = 65536


def error(rid, code: int, message: str) -> dict:
    return {'jsonrpc':'2.0','id':rid,'error':{'code':code,'message':message}}


def parse_json(raw: bytes):
    def reject_duplicates(pairs):
        out = {}
        for key,value in pairs:
            if key in out:
                raise ValueError('Duplicate JSON key')
            out[key] = value
        return out
    def reject_constant(value):
        raise ValueError('Non-finite JSON number')
    return json.loads(raw.decode('utf-8'),object_pairs_hook=reject_duplicates,parse_constant=reject_constant)


class Dispatcher:
    def __init__(self, service: Service):
        self.service = service

    def dispatch(self, obj, principal: Principal, protocol: str = LATEST):
        if isinstance(obj, list):
            if protocol != '2025-03-26' or not 1 <= len(obj) <= 16:
                return error(None, -32600, 'Batches require legacy 2025-03-26 and 1..16 messages')
            if any(isinstance(item, dict) and item.get('method') == 'initialize' for item in obj):
                return error(None, -32600, 'Initialize must be a standalone request')
            # Preflight authorization before executing any write in the batch.
            for item in obj:
                params = item.get('params', {}) if isinstance(item, dict) else {}
                if isinstance(params, dict) and isinstance(params.get('name'), str):
                    tool = self.service.tools.get(params['name'])
                    if tool and tool.write and WRITE not in principal.scopes:
                        raise AuthError(403, 'insufficient_scope', READ+' '+WRITE)
            results = [self.dispatch(item, principal, protocol) for item in obj]
            responses = [item for item in results if item is not None]
            return responses or None
        if not isinstance(obj,dict) or obj.get('jsonrpc')!='2.0':
            return error(None,-32600,'Invalid Request')
        has_id = 'id' in obj
        rid = obj.get('id')
        if has_id and (type(rid) not in (int,str)):
            return error(None,-32600,'MCP request ids must be strings or integers')
        method = obj.get('method')
        if method is None:
            # No server-initiated requests are issued; accept a valid client response.
            if has_id and (('result' in obj) != ('error' in obj)):
                return None
            return error(rid,-32600,'Invalid Request')
        if not isinstance(method,str) or 'result' in obj or 'error' in obj:
            return error(rid,-32600,'Invalid Request')
        params = obj.get('params',{})
        if not isinstance(params,dict):
            return error(rid,-32602,'Params must be an object')
        if not has_id:
            # In particular, never perform a memory write sent as a notification.
            if method.startswith('notifications/'):
                return None
            return error(None,-32600,'This method requires a request id')
        if method.startswith('notifications/'):
            return error(rid,-32600,'Notifications must not contain an id')
        try:
            if method == 'initialize':
                requested = params.get('protocolVersion')
                if not isinstance(requested,str) or not isinstance(params.get('capabilities'),dict) or not isinstance(params.get('clientInfo'),dict):
                    return error(rid,-32602,'Initialize requires protocolVersion, capabilities and clientInfo')
                result = {'protocolVersion':requested if requested in VERSIONS else LATEST,
                          'capabilities':{'tools':{'listChanged':False},'prompts':{'listChanged':False},
                                          'resources':{'subscribe':False,'listChanged':False}},
                          'serverInfo':{'name':'elaina-mcp-unified','version':__version__},
                          'instructions':ANCHOR+' 首次使用或人格丢失时调用 bootstrap_elaina；写记忆需要用户授权。'}
            elif method == 'ping':
                result = {}
            elif method == 'tools/list':
                if params.get('cursor') is not None:
                    return error(rid,-32602,'No pagination cursor was issued')
                result = {'tools':[tool.definition() for tool in self.service.tools.values()]}
            elif method == 'tools/call':
                name,arguments = params.get('name'),params.get('arguments',{})
                if not isinstance(name,str) or name not in self.service.tools:
                    return error(rid,-32602,'Unknown or disabled tool')
                if not isinstance(arguments,dict):
                    return error(rid,-32602,'Tool arguments must be an object')
                if self.service.tools[name].write and WRITE not in principal.scopes:
                    raise AuthError(403,'insufficient_scope',READ+' '+WRITE)
                result = self.service.call(name,arguments,allow_write=WRITE in principal.scopes)
                if protocol == '2025-03-26':
                    result.pop('structuredContent',None)
            elif method == 'prompts/list':
                if params.get('cursor') is not None:
                    return error(rid,-32602,'No pagination cursor was issued')
                result = {'prompts':[{'name':'elaina_full_persona','description':'原 skill 人格原文与 ChatGPT 身份连续性提示词。需要宿主显式使用，不会自行变成系统指令。'}]}
            elif method == 'prompts/get':
                if params.get('name')!='elaina_full_persona' or params.get('arguments') not in (None,{}):
                    return error(rid,-32602,'Unknown prompt or invalid arguments')
                result = {'description':'Elaina user-authorized persona', 'messages':[{
                    'role':'user','content':{'type':'text','text':self.service.persona.export_prompt()}}]}
            elif method == 'resources/list':
                if params.get('cursor') is not None:
                    return error(rid,-32602,'No pagination cursor was issued')
                result = {'resources':[{'uri':'elaina://persona/current','name':'Elaina Persona',
                    'description':'Original persona and ChatGPT host rules.','mimeType':'text/markdown'}]}
            elif method == 'resources/templates/list':
                result = {'resourceTemplates':[]}
            elif method == 'resources/read':
                if params.get('uri')!='elaina://persona/current':
                    return error(rid,-32002,'Resource not found')
                result = {'contents':[{'uri':'elaina://persona/current','mimeType':'text/markdown',
                                      'text':self.service.persona.export_prompt()}]}
            else:
                return error(rid,-32601,'Method not found')
            return {'jsonrpc':'2.0','id':rid,'result':result}
        except AuthError:
            raise
        except Exception as exc:
            logging.getLogger(__name__).warning('RPC failure: method=%s type=%s',method,type(exc).__name__)
            return error(rid,-32603,'Resource unavailable; inspect the server locally')


class RateLimiter:
    """Process-wide private-server limit. Use gateway limits too for public deployments."""
    def __init__(self, limit: int):
        self.limit, self.entries, self.lock = limit, deque(), threading.Lock()

    def take(self) -> bool:
        current = time.monotonic()
        with self.lock:
            while self.entries and self.entries[0] < current-60:
                self.entries.popleft()
            if len(self.entries)>=self.limit:
                return False
            self.entries.append(current)
            return True


class ExactHostMiddleware:
    """Validate parsed hostnames, including bracketed IPv6 authorities."""
    def __init__(self, app, allowed_hosts):
        self.app, self.allowed_hosts = app, frozenset(allowed_hosts)

    async def __call__(self, scope, receive, send):
        if scope['type'] not in ('http', 'websocket'):
            return await self.app(scope, receive, send)
        hosts = Headers(scope=scope).getlist('host')
        try:
            raw = hosts[0] if len(hosts) == 1 else ''
            parsed = urlsplit('//'+raw)
            port = parsed.port  # Reject malformed/non-numeric ports.
            host = parsed.hostname or ''
            authority = '['+host+']' if ':' in host else host
            if port is not None:
                authority += ':'+str(port)
            valid = (bool(raw) and raw.lower() == authority and host in self.allowed_hosts and
                     not any((parsed.username, parsed.password, parsed.path, parsed.query, parsed.fragment)) and
                     not any(c.isspace() for c in raw))
        except ValueError:
            valid = False
        if not valid:
            response = Response('Invalid host header', status_code=400)
            return await response(scope, receive, send)
        return await self.app(scope, receive, send)


def create_app(settings: Settings, service: Service | None = None, authenticator: Authenticator | None = None):
    settings.validate('http')
    service = service or Service(settings)
    auth = authenticator or Authenticator(settings)
    rpc, limiter = Dispatcher(service), RateLimiter(settings.requests_per_minute)
    default_origins = {f'http://127.0.0.1:{settings.port}',f'http://localhost:{settings.port}',f'http://[::1]:{settings.port}'}
    if settings.auth_mode=='oauth':
        default_origins = {settings.origin,'https://chatgpt.com'}
    origins = default_origins | set(settings.allowed_origins)

    async def mcp_endpoint(request: Request):
        origin = request.headers.get('origin')
        if origin is not None and origin not in origins:
            return JSONResponse({'error':'invalid_origin'},status_code=403)
        if not limiter.take():
            return JSONResponse({'error':'rate_limited'},status_code=429,headers={'Retry-After':'60'})
        try:
            principal = await run_in_threadpool(auth.verify,request.headers.get('authorization',''))
        except AuthError as exc:
            return JSONResponse({'error':exc.code},status_code=exc.status,headers={'WWW-Authenticate':auth.challenge(exc)})
        if request.method in ('GET','DELETE'):
            return Response(status_code=405,headers={'Allow':'POST'})
        if request.headers.get('content-type','').split(';')[0].strip().lower()!='application/json':
            return JSONResponse({'error':'application/json required'},status_code=415)
        accept = request.headers.get('accept','')
        if 'application/json' not in accept and '*/*' not in accept:
            return JSONResponse({'error':'Accept application/json, text/event-stream'},status_code=406)
        raw = bytearray()
        async for chunk in request.stream():
            raw.extend(chunk)
            if len(raw)>BODY_LIMIT:
                return JSONResponse({'error':'request_too_large'},status_code=413)
        try:
            obj = parse_json(bytes(raw))
        except (ValueError,UnicodeError,RecursionError):
            return JSONResponse(error(None,-32700,'Parse error'),status_code=400)
        protocol = request.headers.get('mcp-protocol-version','2025-03-26')
        initializing = isinstance(obj,dict) and obj.get('method')=='initialize'
        if protocol not in VERSIONS and not initializing:
            return JSONResponse(error(obj.get('id') if isinstance(obj,dict) else None,-32600,'Unsupported MCP-Protocol-Version'),status_code=400)
        try:
            result = await run_in_threadpool(rpc.dispatch,obj,principal,protocol)
        except AuthError as exc:
            return JSONResponse({'error':exc.code},status_code=exc.status,headers={'WWW-Authenticate':auth.challenge(exc)})
        if result is None:
            return Response(status_code=202)
        headers = {'Cache-Control':'no-store'}
        if initializing and 'result' in result:
            headers['MCP-Protocol-Version'] = result['result']['protocolVersion']
        status = 400 if isinstance(result,dict) and result.get('error',{}).get('code')==-32600 else 200
        return JSONResponse(result,status_code=status,headers=headers)

    async def health(request: Request):
        return JSONResponse({'status':'ok','service':'elaina-mcp-unified','version':__version__})

    async def metadata(request: Request):
        if settings.auth_mode!='oauth':
            return Response(status_code=404)
        return JSONResponse(auth.metadata(),headers={'Cache-Control':'public, max-age=300'})

    app = Starlette(routes=[Route('/mcp',mcp_endpoint,methods=['POST','GET','DELETE']),
                            Route('/mcp/',mcp_endpoint,methods=['POST','GET','DELETE']),
                            Route('/healthz',health,methods=['GET']),
                            Route('/.well-known/oauth-protected-resource',metadata,methods=['GET']),
                            Route('/.well-known/oauth-protected-resource/mcp',metadata,methods=['GET'])])
    hosts = ['127.0.0.1','localhost','::1']
    if settings.public_url:
        hosts.append(urlsplit(settings.public_url).hostname)
    app.add_middleware(ExactHostMiddleware,allowed_hosts=hosts)
    return app


def run_stdio(settings: Settings):
    settings.validate('stdio')
    rpc = Dispatcher(Service(settings))
    principal = Principal(settings.memory_owner,frozenset((READ,WRITE)))
    protocol = LATEST
    # Binary stdio enforces UTF-8 independently of Windows console encoding.
    while True:
        line = sys.stdin.buffer.readline(BODY_LIMIT+2)
        if not line:
            return
        if len(line)>BODY_LIMIT:
            sys.stdout.buffer.write((json.dumps(error(None,-32700,'Message too large'))+'\n').encode())
            sys.stdout.buffer.flush()
            return
        try:
            obj = parse_json(line)
            result = rpc.dispatch(obj,principal,protocol)
            if isinstance(obj,dict) and obj.get('method')=='initialize' and result and 'result' in result:
                protocol = result['result']['protocolVersion']
        except (ValueError,UnicodeError,RecursionError):
            result = error(None,-32700,'Parse error')
        if result is not None:
            sys.stdout.buffer.write((json.dumps(result,ensure_ascii=False)+'\n').encode('utf-8'))
            sys.stdout.buffer.flush()

class ServiceError(Exception):
    """Safe, actionable application error; never include secrets or raw tracebacks."""
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message

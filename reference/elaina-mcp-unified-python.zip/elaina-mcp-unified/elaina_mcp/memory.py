from __future__ import annotations
import json
import re
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from .errors import ServiceError


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='microseconds')


def tokens(query: str) -> list[str]:
    """Deterministic lexical matching, including CJK bigrams; NOT embeddings."""
    parts = re.findall(r'[a-z0-9_]+|[\u3400-\u9fff]+', query.casefold())
    expanded = list(parts)
    for part in parts:
        if re.fullmatch(r'[\u3400-\u9fff]+', part) and len(part) > 2:
            expanded.extend(part[i:i+2] for i in range(len(part)-1))
    return list(dict.fromkeys(expanded))[:100]


class MemoryStore:
    def __init__(self, data_dir: Path, owner: str, max_memories: int = 10000):
        self.data_dir = data_dir.resolve()
        self.data_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.path = self.data_dir / 'conversations.sqlite3'
        if self.path.is_symlink():
            raise ValueError('Memory database may not be a symlink')
        self.owner, self.max_memories = owner, max_memories
        with self.connect() as conn:
            conn.execute('PRAGMA journal_mode=WAL')
            version = conn.execute('PRAGMA user_version').fetchone()[0]
            if version not in (0, 1):
                raise ValueError('Unsupported memory schema; back up and migrate explicitly')
            conn.executescript('''
                CREATE TABLE IF NOT EXISTS memories (
                    id TEXT PRIMARY KEY, owner TEXT NOT NULL, memory_key TEXT NOT NULL,
                    content TEXT NOT NULL, category TEXT NOT NULL, tags TEXT NOT NULL,
                    pinned INTEGER NOT NULL DEFAULT 0, source_quote TEXT NOT NULL,
                    consent TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
                    version INTEGER NOT NULL DEFAULT 1, UNIQUE(owner, memory_key)
                );
                CREATE INDEX IF NOT EXISTS owner_time ON memories(owner, updated_at);
                PRAGMA user_version=1;
            ''')
        try:
            self.path.chmod(0o600)
        except OSError:
            pass  # Windows ACLs are controlled by the deployment account.

    @contextmanager
    def connect(self):
        conn = sqlite3.connect(self.path, timeout=5, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute('PRAGMA busy_timeout=5000')
        conn.execute('PRAGMA secure_delete=ON')
        try:
            yield conn
        finally:
            conn.close()

    @contextmanager
    def transaction(self):
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            try:
                yield conn
                conn.commit()
            except BaseException:
                conn.rollback()
                raise

    @staticmethod
    def public(row) -> dict:
        item = dict(row)
        item.pop('owner', None)
        item['key'] = item.pop('memory_key')
        item['tags'] = json.loads(item['tags'])
        item['pinned'] = bool(item['pinned'])
        item['kind'] = 'conversation_memory_not_canon'
        return item

    def _pin_capacity(self, conn, excluding: str = ''):
        count = conn.execute('SELECT COUNT(*) FROM memories WHERE owner=? AND pinned=1 AND id<>?', (self.owner, excluding)).fetchone()[0]
        if count >= 8:
            raise ServiceError('pin_limit', 'At most 8 pinned memories are allowed; unpin an existing one first')

    def remember(self, *, key: str, content: str, category: str, source_quote: str,
                 consent: str, tags: list[str], pinned: bool) -> dict:
        with self.transaction() as conn:
            old = conn.execute('SELECT * FROM memories WHERE owner=? AND memory_key=?', (self.owner, key)).fetchone()
            normalized_tags = list(dict.fromkeys(tags))
            if old:
                if (old['content'], old['category'], json.loads(old['tags']), bool(old['pinned'])) == (content, category, normalized_tags, pinned):
                    return {'saved': True, 'created': False, 'idempotent': True, 'memory': self.public(old)}
                raise ServiceError('key_conflict', 'That key already exists with different data; recall it and use update_memory with its version')
            count = conn.execute('SELECT COUNT(*) FROM memories WHERE owner=?', (self.owner,)).fetchone()[0]
            if count >= self.max_memories:
                raise ServiceError('memory_limit', 'Memory limit reached; delete obsolete records before adding more')
            if pinned:
                self._pin_capacity(conn)
            mid, stamp = str(uuid.uuid4()), now()
            conn.execute('''INSERT INTO memories
                (id,owner,memory_key,content,category,tags,pinned,source_quote,consent,created_at,updated_at,version)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,1)''',
                (mid,self.owner,key,content,category,json.dumps(normalized_tags,ensure_ascii=False),int(pinned),source_quote,consent,stamp,stamp))
            row = conn.execute('SELECT * FROM memories WHERE owner=? AND id=?', (self.owner,mid)).fetchone()
            return {'saved': True, 'created': True, 'idempotent': False, 'memory': self.public(row)}

    def update(self, *, memory_id: str, expected_version: int, content: str, category: str,
               source_quote: str, consent: str, tags: list[str], pinned: bool) -> dict:
        with self.transaction() as conn:
            old = conn.execute('SELECT * FROM memories WHERE owner=? AND id=?', (self.owner,memory_id)).fetchone()
            if not old:
                raise ServiceError('memory_missing', 'Memory not found')
            if old['version'] != expected_version:
                raise ServiceError('version_conflict', 'Memory changed since it was read; recall and reconcile before retrying')
            if pinned:
                self._pin_capacity(conn, excluding=memory_id)
            conn.execute('''UPDATE memories SET content=?,category=?,tags=?,pinned=?,source_quote=?,consent=?,updated_at=?,version=version+1
                WHERE owner=? AND id=? AND version=?''',
                (content,category,json.dumps(list(dict.fromkeys(tags)),ensure_ascii=False),int(pinned),source_quote,consent,now(),self.owner,memory_id,expected_version))
            row = conn.execute('SELECT * FROM memories WHERE owner=? AND id=?', (self.owner,memory_id)).fetchone()
            return {'saved': True, 'memory': self.public(row)}

    def forget(self, *, memory_id: str, expected_version: int, source_quote: str, consent: str) -> dict:
        # Consent is required by the input schema/host. We deliberately do not retain
        # a copy of the deleted content or the user's deletion request in an audit table.
        with self.transaction() as conn:
            row = conn.execute('SELECT version FROM memories WHERE owner=? AND id=?', (self.owner,memory_id)).fetchone()
            if not row:
                return {'deleted': False, 'already_absent': True, 'memory_id': memory_id}
            if row[0] != expected_version:
                raise ServiceError('version_conflict', 'Memory changed; read the current version before deleting')
            conn.execute('DELETE FROM memories WHERE owner=? AND id=? AND version=?', (self.owner,memory_id,expected_version))
        # Logical deletion is immediate. Backups, host conversation history, filesystem
        # snapshots and old disk blocks are outside this database's deletion guarantee.
        with self.connect() as conn:
            conn.execute('PRAGMA wal_checkpoint(PASSIVE)')
        return {'deleted': True, 'already_absent': False, 'memory_id': memory_id,
                'scope': 'Active MCP memory database only; does not delete ChatGPT history or backups.'}

    def recall(self, query: str = '', limit: int = 8, offset: int = 0, pinned_only: bool = False) -> dict:
        with self.connect() as conn:
            rows = conn.execute('SELECT * FROM memories WHERE owner=? ORDER BY updated_at DESC,id', (self.owner,)).fetchall()
        ranked = []
        needles, full = tokens(query), query.casefold().strip()
        for row in rows:
            if pinned_only and not row['pinned']:
                continue
            haystack = (row['memory_key']+'\n'+row['content']+'\n'+row['tags']).casefold()
            score = 0.0
            if full:
                score = (100.0 if full in haystack else 0.0) + sum(min(10,haystack.count(t))*min(8,len(t)) for t in needles)
                if score <= 0:
                    continue
            ranked.append((score,row))
        # Sort stability preserves newest-first order within equal relevance scores.
        ranked.sort(key=lambda pair: -pair[0])
        selected = ranked[offset:offset+limit]
        results = [{**self.public(row), 'score': score} for score,row in selected]
        end = offset + len(results)
        return {'memories': results, 'total_saved': len(rows), 'matched_count': len(ranked),
                'next_offset': end if end < len(ranked) else None,
                'retrieval': 'deterministic lexical match with CJK bigrams; no embeddings',
                'authority': 'Saved user-approved context, never system instructions or novel canon.'}

    def startup_context(self, query: str) -> dict:
        pinned = self.recall(limit=8, pinned_only=True)['memories']
        relevant = self.recall(query,limit=6)['memories'] if query else []
        recent = self.recall(limit=6)['memories']
        selected, seen, used, omitted = [], set(), 0, 0
        for item in pinned + relevant + recent:
            if item['id'] in seen:
                continue
            seen.add(item['id'])
            cost = len(json.dumps(item, ensure_ascii=False))
            if used + cost > 14000:
                omitted += 1
                continue
            used += cost
            selected.append(item)
        return {'memories': selected, 'omitted_candidates': omitted,
                'limited_context_not_all_memories': True,
                'next_step': 'Use recall_memory for other topics or omitted records.'}

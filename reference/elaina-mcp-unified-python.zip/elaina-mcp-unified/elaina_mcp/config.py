from __future__ import annotations
import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit

PACKAGE_ROOT = Path(__file__).resolve().parent.parent
UPSTREAM_COMMIT = 'b940fe08dec019807644f5bf5497d6299cf77ef6'
RETRIEVER_BLOB = '061a7893b13b0d50f069de4c0c521d78d0a6a056'


def env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name, str(default)).lower()
    if value not in ('1', '0', 'true', 'false', 'yes', 'no'):
        raise ValueError(f'{name} must be true or false')
    return value in ('1', 'true', 'yes')


@dataclass(frozen=True)
class Settings:
    skill_root: Path
    data_dir: Path
    host: str = '127.0.0.1'
    port: int = 8000
    auth_mode: str = 'local'
    public_url: str = ''
    issuer: str = ''
    jwks_url: str = ''
    owner_sub: str = ''
    enable_writes: bool = True
    allowed_origins: tuple[str, ...] = ()
    max_memories: int = 10000
    requests_per_minute: int = 120

    @classmethod
    def from_env(cls) -> 'Settings':
        return cls(
            skill_root=Path(os.getenv('ELAINA_SKILL_ROOT', '../elaina-skill')).expanduser().resolve(),
            data_dir=Path(os.getenv('ELAINA_DATA_DIR', './data')).expanduser().resolve(),
            host=os.getenv('ELAINA_HOST', '127.0.0.1'),
            port=int(os.getenv('ELAINA_PORT', '8000')),
            auth_mode=os.getenv('ELAINA_AUTH_MODE', 'local'),
            public_url=os.getenv('ELAINA_PUBLIC_URL', '').rstrip('/'),
            issuer=os.getenv('ELAINA_OAUTH_ISSUER', ''),
            jwks_url=os.getenv('ELAINA_OAUTH_JWKS_URL', ''),
            owner_sub=os.getenv('ELAINA_OWNER_SUB', ''),
            enable_writes=env_bool('ELAINA_ENABLE_WRITES', True),
            allowed_origins=tuple(x.strip().rstrip('/') for x in os.getenv('ELAINA_ALLOWED_ORIGINS', '').split(',') if x.strip()),
            requests_per_minute=int(os.getenv('ELAINA_REQUESTS_PER_MINUTE', '120')),
        )

    def validate(self, transport: str = 'http') -> None:
        root, data = self.skill_root.resolve(), self.data_dir.resolve()
        if data == root or data.is_relative_to(root):
            raise ValueError('ELAINA_DATA_DIR must be outside the original skill root')
        if self.auth_mode not in ('local', 'oauth'):
            raise ValueError('ELAINA_AUTH_MODE must be local or oauth')
        if not 1 <= self.port <= 65535 or not 1 <= self.requests_per_minute <= 10000:
            raise ValueError('Invalid port or rate limit')
        if self.auth_mode == 'local' and transport == 'http' and self.host not in ('127.0.0.1', '::1', 'localhost'):
            raise ValueError('Unauthenticated HTTP is loopback-only; configure OAuth for remote access')
        if transport == 'stdio' and self.auth_mode != 'local':
            raise ValueError('stdio uses OS process permissions; use ELAINA_AUTH_MODE=local')
        if self.auth_mode == 'oauth':
            for label, value in [('PUBLIC_URL', self.public_url), ('OAUTH_ISSUER', self.issuer), ('OAUTH_JWKS_URL', self.jwks_url)]:
                p = urlsplit(value)
                if p.scheme != 'https' or not p.hostname or p.username or p.password or p.fragment or p.query:
                    raise ValueError(f'ELAINA_{label} must be a configured HTTPS URL without credentials/query/fragment')
            if urlsplit(self.public_url).path != '/mcp':
                raise ValueError('ELAINA_PUBLIC_URL must end with exactly /mcp')
            if not self.owner_sub.strip():
                raise ValueError('ELAINA_OWNER_SUB is required: this is a single-owner private server')
        for origin in self.allowed_origins:
            p = urlsplit(origin)
            if p.scheme not in ('http', 'https') or not p.hostname or p.path or p.query or p.fragment or p.username:
                raise ValueError('Allowed origins must be exact origins, not wildcards or paths')

    @property
    def origin(self) -> str:
        p = urlsplit(self.public_url)
        return f'{p.scheme}://{p.netloc}' if p.netloc else ''

    @property
    def memory_owner(self) -> str:
        # No model-controlled user_id/namespace: every authorized request has one owner.
        return self.owner_sub if self.auth_mode == 'oauth' else 'local-owner'

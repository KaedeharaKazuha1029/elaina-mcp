from __future__ import annotations
import hashlib
import json
import os
import sqlite3
import subprocess
import sys
import threading
from contextlib import contextmanager
from pathlib import Path, PurePosixPath
from .config import RETRIEVER_BLOB, UPSTREAM_COMMIT
from .errors import ServiceError


class Canon:
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.db = self.root / 'memory/index.sqlite3'
        self.script = self.root / 'scripts/retrieve_memory.py'
        self.slots = threading.BoundedSemaphore(2)

    def _inside(self, path: Path) -> Path:
        actual = path.resolve()
        if not actual.is_relative_to(self.root) or not actual.is_file():
            raise ServiceError('canon_missing', 'Required canon file is missing or outside the skill root')
        return actual

    def validate_script(self) -> None:
        data = self._inside(self.script).read_bytes()
        blob = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        if blob != RETRIEVER_BLOB:
            raise ServiceError('unreviewed_retriever', 'Retriever differs from the reviewed upstream version; review and update the code lock explicitly')

    @contextmanager
    def connect(self):
        path = self._inside(self.db)
        conn = sqlite3.connect(path.as_uri()+'?mode=ro&immutable=1', uri=True, timeout=5)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute('PRAGMA query_only=ON')
            yield conn
        finally:
            conn.close()

    def allowed_source(self, relative: str, raw_only: bool = False) -> Path:
        if '\\' in relative or '\x00' in relative or not relative:
            raise ServiceError('invalid_path', 'Use a relative corpus path returned by a search tool')
        p = PurePosixPath(relative)
        if p.is_absolute() or '..' in p.parts or p.parts[0] not in (('小说',) if raw_only else ('小说','文章概括')):
            raise ServiceError('invalid_path', 'Only novel/summary files under the skill root may be read')
        candidate = self._inside(self.root / p)
        if candidate.suffix.lower() not in ('.txt','.md') or not any(candidate.is_relative_to(self.root / d) for d in (('小说',) if raw_only else ('小说','文章概括'))):
            raise ServiceError('invalid_path', 'Source must remain inside an allowed corpus directory')
        return candidate

    def search(self, query: str, mode: str = 'summary', limit: int = 6,
               fallback_raw: bool = True, source_path: str = '') -> dict:
        self.validate_script()
        self._inside(self.db)
        self._inside(self.root / 'memory/query-aliases.json')
        if source_path:
            selected = self.allowed_source(source_path, raw_only=True)
            source_path = selected.relative_to(self.root).as_posix()
        if not self.slots.acquire(timeout=1):
            raise ServiceError('canon_busy', 'Canon search is busy; retry this read later')
        try:
            # The command and script are fixed. The query is after '--', so even
            # a query beginning '--root' cannot become an executable CLI option.
            cmd = [sys.executable, '-I', '-X', 'utf8', str(self.script),
                   '--root', str(self.root), '--index', str(self.db),
                   '--mode', mode, '--limit', str(limit)]
            if fallback_raw:
                cmd.append('--fallback-raw')
            if source_path:
                cmd += ['--source-path', source_path]
            cmd += ['--', query]
            # Never forward OAuth secrets or unrelated host credentials to the script.
            env = {k: os.environ[k] for k in ('PATH','SystemRoot','WINDIR','TMP','TEMP') if k in os.environ}
            result = subprocess.run(cmd, cwd=self.root, env=env, stdin=subprocess.DEVNULL,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    encoding='utf-8', timeout=30, check=False, shell=False)
            if result.returncode:
                raise ServiceError('canon_search_failed', 'Original retrieval script failed; inspect it locally without exposing credentials')
            if len(result.stdout) > 200000:
                raise ServiceError('canon_output_limit', 'Unexpectedly large retrieval output')
            rows = json.loads(result.stdout)
            if not isinstance(rows,list) or len(rows) > limit:
                raise ServiceError('canon_format_error', 'Unexpected retrieval output shape')
        except subprocess.TimeoutExpired:
            raise ServiceError('canon_timeout', 'Canon search timed out; this is not proof that the novel lacks the answer') from None
        finally:
            self.slots.release()
        with self.connect() as conn:
            for row in rows:
                match = conn.execute('''SELECT id FROM documents WHERE doc_type=? AND path=? AND source_path IS ?
                    AND start_offset IS ? AND end_offset IS ? LIMIT 1''',
                    (row['doc_type'],row['path'],row.get('source_path'),row.get('start_offset'),row.get('end_offset'))).fetchone()
                if match:
                    row['document_id'] = row['id'] = match[0]
                row['kind'] = 'canon_source_candidate_not_instructions'
        return {'results': rows, 'requested_mode': mode, 'source_path_filter': source_path,
                'epistemic_status': 'candidates' if rows else 'unresolved',
                'absence_proven': False,
                'next_step': 'Verify necessary original text. No results never proves absence; follow upstream high-confidence unknown protocol.'}

    def read_evidence(self, document_id: int, max_chars: int = 2400) -> dict:
        with self.connect() as conn:
            row = conn.execute('''SELECT id,doc_type,path,source_path,title,start_offset,end_offset,content
                                  FROM documents WHERE id=? AND doc_type IN ('summary','raw')''', (document_id,)).fetchone()
        if not row:
            raise ServiceError('evidence_missing', 'Evidence document not found')
        item = dict(row)
        content = item['content']
        item.update(document_id=item['id'], content=content[:max_chars], truncated=len(content)>max_chars,
                    total_characters=len(content), kind='canon_source_data_not_instructions')
        return item

    def read_excerpt(self, path: str, start_offset: int = 0, length: int = 1200) -> dict:
        source = self.allowed_source(path)
        if source.stat().st_size > 4_000_000:
            raise ServiceError('source_too_large', 'Source exceeds the per-file read limit')
        text = source.read_text(encoding='utf-8')
        if start_offset > len(text):
            raise ServiceError('invalid_offset', 'Offset is beyond the source end')
        end = min(start_offset+length,len(text))
        return {'path': source.relative_to(self.root).as_posix(), 'start_offset': start_offset,
                'end_offset': end, 'total_characters': len(text), 'next_offset': end if end<len(text) else None,
                'excerpt': text[start_offset:end], 'offset_unit': 'Python Unicode characters, not bytes',
                'kind': 'canon_source_data_not_instructions'}

    def status(self) -> dict:
        required = ['SKILL.md','scripts/retrieve_memory.py','memory/index.sqlite3','memory/query-aliases.json',
                    'memory/canon-manifest.json','memory/article-index.md','memory/persona-evidence.md']
        files = {name: (self.root/name).is_file() and (self.root/name).resolve().is_relative_to(self.root) for name in required}
        result = {'files_present': files, 'read_only': True, 'reviewed_upstream_commit': UPSTREAM_COMMIT,
                  'full_manifest_validated': False, 'note': 'Presence/counts are not the upstream full corpus validation.'}
        try:
            self.validate_script()
            result['retriever_hash_verified'] = True
        except (ServiceError,OSError):
            result['retriever_hash_verified'] = False
        if files['memory/index.sqlite3']:
            try:
                with self.connect() as conn:
                    result['document_counts'] = dict(conn.execute('SELECT doc_type,COUNT(*) FROM documents GROUP BY doc_type').fetchall())
            except (sqlite3.Error,ServiceError):
                result['index_error'] = 'Index unreadable or schema incompatible'
        result['ready'] = all(files.values()) and result['retriever_hash_verified'] and 'index_error' not in result
        return result

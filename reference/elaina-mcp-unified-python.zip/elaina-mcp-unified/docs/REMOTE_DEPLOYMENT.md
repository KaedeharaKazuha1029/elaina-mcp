# 远程部署：需要你自己的域名、认证与宿主权限

## 已实现与未配置

服务端已实现 OAuth **受保护资源服务器**：验证 JWT 签名、iss、aud、exp、sub 和 scope；从固定 JWKS 地址获取公钥；只允许一个指定 owner。它不签发登录凭证，不代建 OAuth 授权服务器，也没有用户密码数据库。

部署前必须有可信的 OAuth/OIDC 授权服务器，能提供发现文档、用户登录、授权码流程与 PKCE S256，并能签发给本 MCP 资源使用的 JWT access token。把 ChatGPT 界面给出的实际回调 URL 登记到提供商，按提供商支持方式配置客户端注册；不在本包中猜测回调地址。

令牌必须满足：

| 字段 | 要求 |
|---|---|
| `alg` | RS256 或 ES256 |
| `iss` | 与 ELAINA_OAUTH_ISSUER 完全相同，包括尾部斜杠 |
| `aud` | 包含 ELAINA_PUBLIC_URL，必须是完整 /mcp 端点 |
| `sub` | 与 ELAINA_OWNER_SUB 完全相同 |
| `exp` | 有效的到期时间；校验允许 15 秒时钟误差 |
| `scope` / `scp` | 读操作需要 elaina:read；写操作还需要 elaina:write |

不支持 opaque access token 的在线 introspection。不能把别的 API 的 token、ID token 或任意字符串当作访问本服务的 access token。提供商如果只发通用 API audience，需要配置正确的资源 audience；不能删掉服务端 aud 校验来省事。

为长期连接配置提供商支持的 refresh token / offline_access。是否需要额外离线访问设置，应以提供商和 ChatGPT 当前界面为准。

## Docker 示例

建议目录结构：原仓库 `../elaina-skill`，合并服务当前目录。准备 `.env.remote`：

```bash
cp .env.remote.example .env.remote
# 编辑 .env.remote，替换域名、issuer、JWKS、owner sub 等全部占位符。
docker compose up -d --build
docker compose logs --tail=50 elaina-mcp
```

镜像中的进程使用非 root UID/GID 10001。原仓库挂载只读；独立命名卷挂载 `/data`。Compose 只把端口发布到服务器回环地址，再由 HTTPS 反向代理转发。首次创建的数据卷应允许 UID 10001 写入；不要用 chmod 777 解决权限问题。

复制并修改 `Caddyfile.example`，由你管理的 Caddy 提供有效 HTTPS。反向代理需保留 Authorization、MCP-Protocol-Version、Origin 和外部 Host；不要在响应日志中记录令牌或工具正文。本包不自动安装 Caddy，也未验证具体云主机的端口、防火墙、DNS、证书条件。

服务路径：

```text
https://你的域名/mcp
https://你的域名/.well-known/oauth-protected-resource/mcp
https://你的域名/.well-known/oauth-protected-resource
https://你的域名/healthz
```

`/mcp` 的 GET 返回 405 是正常的：本实现采用 POST 的 JSON 响应，不提供 GET SSE 流。无登录时得到 401 + WWW-Authenticate 用于发现授权信息，也是预期行为。

## 验证及接入

先在自己的终端获取正确 access token，以环境变量传给自检，不要把 token 贴给模型：

```bash
export ELAINA_ACCESS_TOKEN='你的临时访问令牌'
python scripts/smoke_test.py --url https://你的域名/mcp
# 明确授权自检写入和清理时才运行：
python scripts/smoke_test.py --url https://你的域名/mcp --write-test
unset ELAINA_ACCESS_TOKEN
```

然后在具备相应权限的 ChatGPT 网页账户/工作区创建自定义 MCP app，填端点、完成 OAuth、扫描工具、确认实际显示的读写权限；再选中 app 调用 bootstrap。先放好常驻身份短指令，不能把扫描成功视为人格已持续加载。

2026-10-12 查询的 OpenAI 官方说明：完整 MCP（包括写入）面向 Business/Enterprise/Edu；Pro 可在开发者模式使用 read/fetch。功能处于变化中，你的实际账户和工作区权限应现场核对。不能承诺某种订阅一定能调用本包的写记忆工具；无权限时可设置 ELAINA_ENABLE_WRITES=false 保留人格和只读能力。

官方还说明 app 的显式选择通常针对当前消息；需要新数据/新操作时可能需再次 @app。常驻身份指令与 app 是否在当前消息可调用是两回事。代码更新改变工具定义后，需要刷新宿主缓存的工具快照。

本版本为单 owner 私有服务；不要把同一个部署分享给其他用户并让大家使用同一 owner。计划多用户服务时，需要按可信认证主体分区并重新设计授权、数据生命周期与部署审计。

## 依据

- https://help.openai.com/en/articles/12584461-developer-mode-and-mcp-apps-in-chatgpt
- https://modelcontextprotocol.io/specification/2025-11-25/basic/authorization
- https://modelcontextprotocol.io/specification/2025-11-25/basic/transports

这些说明不能替代实际部署验收。本次未取得你的域名、服务器配置、OAuth 提供商或 ChatGPT 自定义 app 管理权限，因此没有执行远程上线。

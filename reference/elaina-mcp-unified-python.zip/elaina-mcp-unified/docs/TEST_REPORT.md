# 实际测试报告

准备日期：2026-10-12。最终运行结果：**86 passed，0 failed，0 skipped**。
本轮 pytest 报告的总用时约 11.61 秒。原始日志见 `verification.log`，机器可读结果见 `verification.junit.xml`。

## 实际运行环境

- Python：3.13.5；系统：Linux x86_64。
- 包版本：`{"starlette": "0.50.0", "uvicorn": "0.48.0", "pydantic": "2.13.5", "PyJWT": "2.13.0", "cryptography": "46.0.4", "httpx": "0.28.1", "pytest": "9.0.2"}`。
- 全部服务代码及辅助脚本通过 Python 字节码编译检查。

## 已执行并通过

| 检查 | 实际验证方式 |
|---|---|
| 上游原件 | 六个原文件的 Git blob SHA-1 与仓库核对值相同 |
| 人格加载 | bootstrap 返回四份人格全文，分页读取无静默截断 |
| 前置输出提示词 | 断言文本包含第一条可见输出、身份先于工具、恢复与诚实规则；不是模型输出实验 |
| 对话记忆 | 新增、幂等重试、查询、修正、版本冲突、删除、重复删除 |
| 并发与隔离 | 并发重复写入仅创建一条；不同 owner 互不可读/删 |
| 授权和验证 | 缺失授权字段、非法类别、任意 user_id、超长文本、非法路径等拒绝 |
| 原 Python + SQL | 实际启动上游 retrieve_memory.py 检索合成数据库，摘要/raw/combined、别名、回退、来源过滤、ID 回读 |
| 原作不被写入 | 读取前后原库文件哈希相同；只读连接拒绝 DELETE |
| 路径和代码边界 | 路径穿越、语料外文件、越界符号链接、变更后的检索脚本被拒绝 |
| HTTP 协议 | 初始化、版本协商、11 工具、prompts/resources、通知 202、JSON 内容、旧版 batch |
| HTTP 防护 | Origin、Host（含 IPv6 authority）、体积、速率、内容类型、版本头检查 |
| OAuth 资源校验 | 本地生成 RSA 测试密钥签发 JWT，检验 issuer/audience/expiry/owner/读写 scope；未连接真实提供商 |
| 真实 stdio 进程 | 启动、写入、退出、重新启动、查询仍有记录 |
| 真实 HTTP 进程 | 本地 Uvicorn 启动、加载人格、保存、终止、重新启动、查询、删除后查询为空 |
| 部署辅助程序 | 实际运行 smoke_test.py --write-test，对本地服务完成写/读/清理 |

## 输出提示词

常驻短版：775 个 Unicode 字符。完整版本：6981 个 Unicode 字符。
完整版本包含新宿主规则及原 skill 的 SOUL、IDENTITY、PERSONA_ELAINA、RUNTIME_GUARD 原文。
这证明文件已生成且原件完整，不证明 ChatGPT 会在所有轮次采纳全部指令。

## 未验证或未执行

**没有完整小说库的端到端测试。** 本环境未取得完整原作 SQLite 和全部小说，使用临时合成小说/摘要/数据库来执行真实原 Python 和 SQL。因此不宣称 296 篇小说、296 篇概括或每条原作事实已重新核验；实际部署须使用原仓库数据并检查原上游的校验流程。

**没有 ChatGPT 网页/移动端连接验收。** 未验证你的账户写权限、工具选择、OAuth 登录、首句生成或上下文压缩后的实际模型表现。MCP 返回和 prompt 文本不是宿主强制钩子；人工验收步骤见 CHATGPT_ACCEPTANCE.md。

**没有远程上线。** 未修改 GitHub、未部署到你的服务器、未设置 DNS/证书、未提供真实 OAuth 凭证、未构建 Docker 镜像、未在 Windows 运行，也未用 MCP Inspector/官方 SDK 做外部互操作认证。

## 复现

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q --junitxml=docs/verification.junit.xml
```

原件位于 `tests/fixtures/upstream`，只含检索代码、人格和协议文档。合成文本与 SQLite 在测试临时目录创建，运行结束不应作为真实原作或私有记忆分发。

# 源码和协议依据

查阅日期：2026-10-12。固定协议基线不是“永远最新版本”的声明。

## 用户原仓库

- https://github.com/KaedeharaKazuha1029/elaina-skill
- 核对提交：b940fe08dec019807644f5bf5497d6299cf77ef6
- SKILL.md：可见第一句、人设持续性、原作不编造与 OpenClaw 专属机制。
- assets/openclaw-workspace/SOUL.md、IDENTITY.md、PERSONA_ELAINA.md、RUNTIME_GUARD.md：人格原件。
- scripts/retrieve_memory.py：实际调用的 Python / SQLite 检索逻辑。
- references/retrieval-protocol.md：摘要→原文与未知门槛。
- upstream.lock.json：本包保留原件的 Git blob 与 SHA-256 校验值。

## 两个输入包

- elaina-mcp-addon.zip：统一检索、字符偏移片段、人设文档与状态检查。
- elaina-mcp-bridge.zip：拆分检索、文档 ID 证据读取、无状态远程接口思路。

## 官方文档

- https://help.openai.com/en/articles/12584461-developer-mode-and-mcp-apps-in-chatgpt
- https://modelcontextprotocol.io/specification/2025-11-25/basic/transports
- https://modelcontextprotocol.io/specification/2025-11-25/basic/lifecycle
- https://modelcontextprotocol.io/specification/2025-11-25/basic/authorization
- https://modelcontextprotocol.io/specification/2025-11-25/server/tools
- https://modelcontextprotocol.io/specification/2025-03-26/basic/transports

这次的开发环境没有可安装的 MCP Python SDK，且无法完整克隆原小说仓库。因此交付包含可运行的自带协议实现、已验证原脚本及合成测试，不冒充官方 SDK/Inspector 互操作认证或全量原文验证。官方 SDK 主分支 API 已有变化，不能照搬旧包中未锁定版本的 FastMCP 写法就声称兼容。

# 原 skill 适配范围

| 原件或机制 | 本版处理 |
|---|---|
| SOUL / IDENTITY / PERSONA_ELAINA | bootstrap 返回原文；完整 prompt 同样保留，不重新概括人格 |
| RUNTIME_GUARD | 返回原文，宿主规则补充 MCP 前置可见输出与错误恢复 |
| SKILL 的第一句身份协议 | 迁入宿主短/完整规则，明确身份先于是否调用工具 |
| 原作/当前对话/角色即时判断分离 | 原数据库只读，新库按类别保存，roleplay 不进入正典 |
| 摘要优先与别名召回 | 实际运行原 retrieve_memory.py，不换成未经说明的向量算法 |
| 原文核验 | source_path、document_id、字符片段组成证据回读通路 |
| 高置信 unknown 门槛 | 完整 retrieval-protocol.md 随 bootstrap 返回；零命中标 unresolved |
| 已核验人格档案 | 原文保留其声明；本版没有重新核验完整小说，也不另造“已验证”结论 |
| OpenClaw 自动每轮 Project Context 注入 | 不适用于 ChatGPT；不执行 install_openclaw_injection.mjs，不伪造 system role |
| OpenClaw AGENTS 安装/迁移/主机管理命令 | 不在 ChatGPT 自动执行；白名单读取仅用于用户主动技术诊断 |
| USER.md / MEMORY.md / 历史 transcript | 不自动导入；本服务只保存用户明确批准的独立条目 |
| “任何情况下不以 AI 自称”等风格绝对句 | 原件保留，但宿主适配规则明确：直接询问真实身份/执行情况时如实回答 |

新传输层不沿用旧包的 FastMCP 版本依赖；使用独立的、测试覆盖的协议子集。两个旧包本身没有对话长期记忆库，因此不存在必须迁移的旧版对话表。本版不会自行删除旧包或原仓库。

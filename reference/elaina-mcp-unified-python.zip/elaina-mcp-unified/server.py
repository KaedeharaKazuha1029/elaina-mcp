#!/usr/bin/env python3
"""Start the private Elaina MCP service. Configuration is from ELAINA_* env vars."""
from __future__ import annotations
import argparse
import logging
from elaina_mcp.config import Settings
from elaina_mcp.transport import create_app, run_stdio


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--transport',choices=['http','stdio'],default='http')
    args = parser.parse_args()
    settings = Settings.from_env()
    settings.validate(args.transport)
    logging.basicConfig(level=logging.WARNING)
    if args.transport=='stdio':
        run_stdio(settings)
    else:
        import uvicorn
        uvicorn.run(create_app(settings),host=settings.host,port=settings.port,
                    log_level='warning',access_log=False,proxy_headers=False,limit_concurrency=32)

if __name__=='__main__':
    main()

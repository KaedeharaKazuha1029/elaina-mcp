from __future__ import annotations
import json
import shutil
import sqlite3
from pathlib import Path
import pytest
from elaina_mcp.config import Settings
from elaina_mcp.service import Service

FIXTURES = Path(__file__).parent / 'fixtures/upstream'
RAW_PATH = '小说/测试卷/测试篇.txt'
RAW_TEXT = '【合成测试数据，不是魔女之旅原作】\n测试旅人找到青色钥匙。\n测试钟楼的门在下午打开。\n'

@pytest.fixture
def settings(tmp_path):
    root = tmp_path/'elaina-skill'
    shutil.copytree(FIXTURES, root)
    raw = root/RAW_PATH
    raw.parent.mkdir(parents=True)
    raw.write_text(RAW_TEXT,encoding='utf-8')
    summary = root/'文章概括/测试篇.md'
    summary.parent.mkdir()
    summary_text = '【合成测试摘要】测试旅人得到青色钥匙。'
    summary.write_text(summary_text,encoding='utf-8')
    (root/'memory').mkdir()
    (root/'SKILL.md').write_text('# Synthetic fixture stub, not the original SKILL.md\n',encoding='utf-8')
    for f in ['article-index.md','persona-evidence.md']:
        (root/'memory'/f).write_text('SYNTHETIC TEST ONLY',encoding='utf-8')
    (root/'memory/canon-manifest.json').write_text(json.dumps({'synthetic_test_only':True}),encoding='utf-8')
    (root/'memory/query-aliases.json').write_text(json.dumps({'青色钥匙':['青钥匙']},ensure_ascii=False),encoding='utf-8')
    conn = sqlite3.connect(root/'memory/index.sqlite3')
    conn.execute('''CREATE TABLE documents (id INTEGER PRIMARY KEY,doc_type TEXT,path TEXT,
                 source_path TEXT,title TEXT,start_offset INTEGER,end_offset INTEGER,content TEXT)''')
    conn.executemany('INSERT INTO documents VALUES(?,?,?,?,?,?,?,?)',[
        (1,'summary','文章概括/测试篇.md',RAW_PATH,'合成测试篇',None,None,summary_text),
        (2,'raw',RAW_PATH,RAW_PATH,'合成测试篇',0,len(RAW_TEXT),RAW_TEXT),
    ])
    conn.commit(); conn.close()
    return Settings(root,tmp_path/'private-memory',requests_per_minute=10000)

@pytest.fixture
def service(settings):
    return Service(settings)

@pytest.fixture
def memory_args():
    return {'key':'test.preference','content':'测试用户喜欢青色。','category':'preference',
            'source_quote':'请记住：测试用户喜欢青色。','consent':'user_requested','tags':['测试'],'pinned':False}

def envelope(service,name,args=None):
    return service.call(name,args or {})['structuredContent']

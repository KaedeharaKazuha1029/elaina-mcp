from __future__ import annotations
import json
import os
import socket
import subprocess
import sys
import time
from dataclasses import replace
from types import SimpleNamespace
from contextlib import contextmanager
import httpx
import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from starlette.testclient import TestClient
from elaina_mcp.auth import Authenticator, AuthError, Principal, READ, WRITE
from elaina_mcp.transport import create_app, Dispatcher, VERSIONS, BODY_LIMIT, parse_json
from elaina_mcp.service import Service
from elaina_mcp.config import PACKAGE_ROOT

HEADERS={'Accept':'application/json, text/event-stream','MCP-Protocol-Version':'2025-11-25'}

def req(method,params=None,rid=1):
    return {'jsonrpc':'2.0','id':rid,'method':method,'params':params or {}}

def init(version='2025-11-25'):
    return req('initialize',{'protocolVersion':version,'capabilities':{},'clientInfo':{'name':'local-test','version':'1'}})

@pytest.fixture
def client(settings):
    with TestClient(create_app(settings),base_url='http://127.0.0.1:8000',headers=HEADERS) as c:
        yield c

@pytest.mark.parametrize('version',VERSIONS+('unknown-future-version',))
def test_initialize_negotiation(client,version):
    r=client.post('/mcp',json=init(version)); assert r.status_code==200,r.text
    assert r.json()['result']['protocolVersion']==(version if version in VERSIONS else VERSIONS[-1])
    assert '伊蕾娜' in r.json()['result']['instructions']
    assert 'Mcp-Session-Id' not in r.headers

def test_http_tool_discovery_call_and_notification(client,memory_args):
    tools=client.post('/mcp',json=req('tools/list')).json()['result']['tools']
    assert len(tools)==11
    assert next(t for t in tools if t['name']=='remember_memory')['annotations']['readOnlyHint'] is False
    b=client.post('/mcp',json=req('tools/call',{'name':'bootstrap_elaina'})).json()['result']
    assert not b['isError']
    assert b['structuredContent']['data']['initialization_complete']
    assert json.loads(b['content'][0]['text'])==b['structuredContent']
    saved=client.post('/mcp',json=req('tools/call',{'name':'remember_memory','arguments':memory_args})).json()['result']
    assert saved['structuredContent']['data']['saved']
    r=client.post('/mcp',json={'jsonrpc':'2.0','method':'notifications/initialized'})
    assert r.status_code==202 and not r.content
    old=client.post('/mcp',headers={'MCP-Protocol-Version':'2025-03-26'},json=req('tools/call',{'name':'recall_memory'}))
    assert 'structuredContent' not in old.json()['result']
    assert json.loads(old.json()['result']['content'][0]['text'])['data']['total_saved']==1

def test_prompts_resources(client):
    for method,key in [('prompts/list','prompts'),('resources/list','resources')]:
        assert len(client.post('/mcp',json=req(method)).json()['result'][key])==1
    p=client.post('/mcp',json=req('prompts/get',{'name':'elaina_full_persona'})).json()['result']
    assert '第一条可见输出' in p['messages'][0]['content']['text']
    r=client.post('/mcp',json=req('resources/read',{'uri':'elaina://persona/current'})).json()['result']
    assert r['contents'][0]['mimeType']=='text/markdown'
    assert 'SOUL.md' in r['contents'][0]['text']

@pytest.mark.parametrize('method',['get','delete'])
def test_no_sse_or_session_delete(client,method):
    r=getattr(client,method)('/mcp'); assert r.status_code==405

def test_origin_host_version_media_and_limits(client):
    assert client.post('/mcp',headers={'Origin':'https://evil.example'},json=req('ping')).status_code==403
    assert client.post('/mcp',headers={'Host':'evil.example'},json=req('ping')).status_code==400
    assert client.post('/mcp',headers={'MCP-Protocol-Version':'invalid'},json=req('ping')).status_code==400
    assert client.post('/mcp',headers={'Content-Type':'text/plain'},content='{}').status_code==415
    assert client.post('/mcp',headers={'Accept':'text/plain'},json=req('ping')).status_code==406
    assert client.post('/mcp',headers={'Content-Type':'application/json'},content='x'*(BODY_LIMIT+1)).status_code==413
    assert client.get('/healthz').json()['status']=='ok'

def test_rate_limit(settings):
    with TestClient(create_app(replace(settings,requests_per_minute=1)),base_url='http://127.0.0.1:8000',headers=HEADERS) as c:
        assert c.post('/mcp',json=req('ping')).status_code==200
        assert c.post('/mcp',json=req('ping')).status_code==429

@pytest.mark.parametrize('obj',[
 [],None,{}, {'jsonrpc':'1.0','id':1,'method':'ping'},
 {'jsonrpc':'2.0','id':True,'method':'ping'},
 {'jsonrpc':'2.0','id':None,'method':'ping'},
 {'jsonrpc':'2.0','id':1,'method':'ping','params':[]},
 {'jsonrpc':'2.0','id':1,'method':'notifications/initialized'},
 {'jsonrpc':'2.0','method':'tools/call','params':{'name':'remember_memory'}},
])
def test_invalid_protocol_cannot_mutate(service,obj):
    out=Dispatcher(service).dispatch(obj,Principal('local-owner',frozenset((READ,WRITE))))
    assert 'error' in out
    assert service.memory.recall()['total_saved']==0

@pytest.mark.parametrize('text',['{"x":1,"x":2}','{"x":NaN}','{"x":Infinity}','{'])
def test_strict_json(client,text):
    r=client.post('/mcp',content=text,headers={'Content-Type':'application/json'})
    assert r.status_code==400 and r.json()['error']['code']==-32700

@pytest.fixture
def oauth_setup(settings,monkeypatch):
    s=replace(settings,host='0.0.0.0',auth_mode='oauth',public_url='https://mcp.example.test/mcp',
        issuer='https://issuer.example.test/',jwks_url='https://issuer.example.test/jwks',owner_sub='owner-123')
    auth=Authenticator(s)
    key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    monkeypatch.setattr(auth.jwks,'get_signing_key_from_jwt',lambda token:SimpleNamespace(key=key.public_key()))
    def token(**changes):
        claims={'iss':s.issuer,'aud':s.public_url,'sub':s.owner_sub,'exp':int(time.time())+300,'iat':int(time.time()),'scope':READ+' '+WRITE}
        claims.update(changes)
        return jwt.encode(claims,key,algorithm='RS256',headers={'kid':'test-key'})
    return s,auth,token

def test_oauth_metadata_and_bearer_validation(oauth_setup):
    s,a,token=oauth_setup
    assert a.verify('Bearer '+token()).subject=='owner-123'
    with TestClient(create_app(s,authenticator=a),base_url=s.origin,headers=HEADERS) as c:
        m=c.get('/.well-known/oauth-protected-resource/mcp').json()
        assert m['resource']==s.public_url and WRITE in m['scopes_supported']
        denied=c.post('/mcp',json=req('tools/list'))
        assert denied.status_code==401
        assert 'resource_metadata=' in denied.headers['WWW-Authenticate']
        accepted=c.post('/mcp',json=req('tools/list'),headers={'Authorization':'Bearer '+token()})
        assert accepted.status_code==200

@pytest.mark.parametrize('change,status',[
 ({'aud':'https://wrong.test/mcp'},401),({'iss':'https://wrong.test/'},401),
 ({'exp':1},401),({'sub':'another-owner'},403),({'scope':WRITE},403),
 ({'scope':None},403),({'exp':None},401),
])
def test_oauth_rejects_bad_claims(oauth_setup,change,status):
    _,auth,token=oauth_setup
    with pytest.raises(AuthError) as e: auth.verify('Bearer '+token(**change))
    assert e.value.status==status

def test_oauth_write_scope_enforced(oauth_setup,memory_args):
    s,a,token=oauth_setup
    with TestClient(create_app(s,authenticator=a),base_url=s.origin,headers=HEADERS) as c:
        read={'Authorization':'Bearer '+token(scope=READ)}
        denied=c.post('/mcp',json=req('tools/call',{'name':'remember_memory','arguments':memory_args}),headers=read)
        assert denied.status_code==403
        assert WRITE in denied.headers['WWW-Authenticate']
        assert c.post('/mcp',json=req('tools/call',{'name':'recall_memory'}),headers=read).json()['result']['structuredContent']['data']['total_saved']==0
        yes=c.post('/mcp',json=req('tools/call',{'name':'remember_memory','arguments':memory_args}),headers={'Authorization':'Bearer '+token()})
        assert yes.json()['result']['structuredContent']['ok']

def subprocess_env(settings,port=8000):
    e=dict(os.environ)
    for k in list(e):
        if k.startswith('ELAINA_'): del e[k]
    e.update(ELAINA_SKILL_ROOT=str(settings.skill_root),ELAINA_DATA_DIR=str(settings.data_dir),
             ELAINA_AUTH_MODE='local',ELAINA_HOST='127.0.0.1',ELAINA_PORT=str(port))
    return e

def test_stdio_real_process_and_restart(settings,memory_args):
    messages=[init(),{'jsonrpc':'2.0','method':'notifications/initialized'},
              req('tools/call',{'name':'remember_memory','arguments':memory_args},2)]
    result=subprocess.run([sys.executable,'server.py','--transport','stdio'],cwd=PACKAGE_ROOT,
        env=subprocess_env(settings),input=''.join(json.dumps(m,ensure_ascii=False)+'\n' for m in messages),
        capture_output=True,text=True,encoding='utf-8',timeout=15)
    assert result.returncode==0,result.stderr
    output=[json.loads(line) for line in result.stdout.splitlines()]
    assert len(output)==2 and output[-1]['result']['structuredContent']['data']['saved']
    second=subprocess.run([sys.executable,'server.py','--transport','stdio'],cwd=PACKAGE_ROOT,
        env=subprocess_env(settings),input=json.dumps(init())+'\n'+json.dumps(req('tools/call',{'name':'recall_memory'},2))+'\n',
        capture_output=True,text=True,encoding='utf-8',timeout=15)
    assert second.returncode==0,second.stderr
    assert json.loads(second.stdout.splitlines()[-1])['result']['structuredContent']['data']['total_saved']==1

@contextmanager
def live_server(settings):
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0)); port=sock.getsockname()[1]
    proc=subprocess.Popen([sys.executable,'server.py'],cwd=PACKAGE_ROOT,env=subprocess_env(settings,port),
                          stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    base=f'http://127.0.0.1:{port}'
    try:
        with httpx.Client(base_url=base,headers=HEADERS,timeout=2,trust_env=False) as client:
            for _ in range(60):
                if proc.poll() is not None:
                    raise AssertionError(proc.stderr.read().decode())
                try:
                    if client.get('/healthz').status_code==200: break
                except httpx.HTTPError: pass
                time.sleep(0.1)
            else: raise AssertionError('Local server failed to start')
            yield client
    finally:
        proc.terminate()
        try: proc.communicate(timeout=5)
        except subprocess.TimeoutExpired: proc.kill();proc.communicate()

def test_live_http_database_survives_server_restart(settings,memory_args):
    with live_server(settings) as c:
        assert c.post('/mcp',json=init()).json()['result']['protocolVersion']==VERSIONS[-1]
        bootstrap=c.post('/mcp',json=req('tools/call',{'name':'bootstrap_elaina'})).json()['result']['structuredContent']
        assert bootstrap['ok']
        saved=c.post('/mcp',json=req('tools/call',{'name':'remember_memory','arguments':memory_args})).json()['result']['structuredContent']
        item=saved['data']['memory']
    with live_server(settings) as c:
        c.post('/mcp',json=init())
        recalled=c.post('/mcp',json=req('tools/call',{'name':'recall_memory'})).json()['result']['structuredContent']
        assert recalled['data']['memories'][0]['id']==item['id']
        args={'memory_id':item['id'],'expected_version':1,'source_quote':'删除合成测试记忆','consent':'user_requested'}
        assert c.post('/mcp',json=req('tools/call',{'name':'forget_memory','arguments':args})).json()['result']['structuredContent']['data']['deleted']
        assert c.post('/mcp',json=req('tools/call',{'name':'recall_memory'})).json()['result']['structuredContent']['data']['total_saved']==0

def test_legacy_batches_and_notification_only(client):
    headers={'MCP-Protocol-Version':'2025-03-26'}
    r=client.post('/mcp',headers=headers,json=[req('ping',rid=1),req('tools/list',rid=2)])
    assert r.status_code==200 and len(r.json())==2
    assert r.json()[0]['result']=={}
    n=client.post('/mcp',headers=headers,json=[{'jsonrpc':'2.0','method':'notifications/initialized'}])
    assert n.status_code==202 and not n.content
    assert client.post('/mcp',json=[req('ping')]).status_code==400
    assert client.post('/mcp',headers=headers,json=[init()]).status_code==400

def test_ipv6_host_validation(settings):
    with TestClient(create_app(replace(settings,host='::1')),base_url='http://127.0.0.1:8000',headers={**HEADERS,'Host':'[::1]:8000'}) as c:
        assert c.post('/mcp',json=req('ping')).status_code==200
        assert c.post('/mcp',headers={'Host':'[::1].evil.test'},json=req('ping')).status_code==400

def test_helper_smoke_script(settings):
    with live_server(settings) as c:
        result=subprocess.run([sys.executable,'scripts/smoke_test.py','--url',str(c.base_url).rstrip('/')+'/mcp','--write-test'],
            cwd=PACKAGE_ROOT,env=subprocess_env(settings),capture_output=True,text=True,encoding='utf-8',timeout=15)
        assert result.returncode==0,result.stderr
        data=json.loads(result.stdout)
        assert data['write_read_test']=='passed' and data['test_memory_deleted']
        assert not data['chatgpt_ui_verified']

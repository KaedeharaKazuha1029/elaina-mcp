from __future__ import annotations
import hashlib
import json
import sqlite3
from dataclasses import replace
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import pytest
from elaina_mcp.service import Service
from elaina_mcp.config import PACKAGE_ROOT
from elaina_mcp.memory import MemoryStore
from elaina_mcp.errors import ServiceError
from conftest import RAW_PATH, RAW_TEXT, FIXTURES, envelope

UPSTREAM_BLOBS = {
 'scripts/retrieve_memory.py':'061a7893b13b0d50f069de4c0c521d78d0a6a056',
 'assets/openclaw-workspace/SOUL.md':'c818f3e7e5c90af704eeb09234f519364425bdf2',
 'assets/openclaw-workspace/IDENTITY.md':'08796fe7382b3a0130ac1dccc738399bc3c11727',
 'assets/openclaw-workspace/PERSONA_ELAINA.md':'6d614eec6fd5020e11e5aa20db19a6820b1b7a90',
 'assets/openclaw-workspace/RUNTIME_GUARD.md':'25d43ff3367924695cd43771a41ae3a5d57e4afb',
 'references/retrieval-protocol.md':'f9875bde47148f1c39620602cbcc616b0fa921b1',
}

@pytest.mark.parametrize('name,expected',UPSTREAM_BLOBS.items())
def test_exact_upstream_blobs(name,expected):
    b=(FIXTURES/name).read_bytes()
    assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==expected

def test_bootstrap_full_original_persona(service):
    e=envelope(service,'bootstrap_elaina')
    assert e['ok'],e
    d=e['data']; assert d['initialization_complete']
    assert len(d['persona']['documents'])==4
    for doc in d['persona']['documents']:
        assert doc['content']==(FIXTURES/doc['path']).read_text(encoding='utf-8')
        assert doc['next_offset'] is None
    assert not d['persona']['replaces_system_instructions']
    assert d['retain_in_conversation']['pre_tool_reply_uses_persona']
    assert d['canon']['full_manifest_validated'] is False

def test_prompt_contract_not_behavior_guarantee(service):
    short=(PACKAGE_ROOT/'prompts/CHATGPT_CUSTOM_INSTRUCTIONS.txt').read_text(encoding='utf-8')
    assert len(short)<=1500
    full=service.persona.export_prompt()
    for term in ['第一条可见输出','身份先于工具','bootstrap_elaina','recall_memory','未读取资料','如实说明']:
        assert term in full
    assert len(full)>len(short)

def test_persona_paging(service):
    e=envelope(service,'get_persona_document',{'document':'SOUL.md','length':20})
    assert e['ok'] and len(e['data']['content'])==20
    assert e['data']['next_offset']==20

def test_memory_crud_persistence_and_versions(service,settings,memory_args):
    saved=envelope(service,'remember_memory',memory_args); assert saved['ok'],saved
    item=saved['data']['memory']; assert item['version']==1
    reopened=Service(settings)
    assert envelope(reopened,'recall_memory',{'query':'青色'})['data']['memories'][0]['id']==item['id']
    retry=envelope(service,'remember_memory',memory_args)
    assert retry['data']['idempotent']
    conflict=envelope(service,'remember_memory',{**memory_args,'content':'不同内容'})
    assert conflict['error']['code']=='key_conflict'
    update={k:v for k,v in memory_args.items() if k!='key'}
    update.update(memory_id=item['id'],expected_version=1,content='测试用户改为喜欢紫色。')
    out=envelope(service,'update_memory',update); assert out['ok']
    assert out['data']['memory']['version']==2
    assert envelope(service,'update_memory',update)['error']['code']=='version_conflict'
    forget={'memory_id':item['id'],'expected_version':1,'source_quote':'删除测试记忆','consent':'user_requested'}
    assert envelope(service,'forget_memory',forget)['error']['code']=='version_conflict'
    forget['expected_version']=2
    assert envelope(service,'forget_memory',forget)['data']['deleted']
    assert envelope(service,'forget_memory',forget)['data']['already_absent']
    assert envelope(Service(settings),'recall_memory')['data']['total_saved']==0

@pytest.mark.parametrize('patch',[
 {'consent':'assumed'}, {'source_quote':''}, {'consent':None}, {'key':'../../pwn'},
 {'category':'canon'}, {'content':''}, {'content':'x'*2001}, {'user_id':'another-user'},
 {'pinned':'true'}, {'tags':['x'*41]},
])
def test_memory_rejects_invalid_or_unconsented(service,memory_args,patch):
    e=envelope(service,'remember_memory',{**memory_args,**patch})
    assert not e['ok']; assert e['error']['code']=='invalid_arguments'
    assert envelope(service,'recall_memory')['data']['total_saved']==0

def test_missing_consent(service,memory_args):
    del memory_args['consent']
    assert not envelope(service,'remember_memory',memory_args)['ok']

def test_separate_owner_sql_literal_and_pins(service,settings,memory_args):
    args={**memory_args,'content':"'; DROP TABLE memories; -- 测试"}
    item=envelope(service,'remember_memory',args)['data']['memory']
    assert envelope(service,'recall_memory')['data']['total_saved']==1
    other=MemoryStore(settings.data_dir,'another-owner')
    assert other.recall()['total_saved']==0
    assert other.forget(memory_id=item['id'],expected_version=1,source_quote='test',consent='user_requested')['already_absent']
    assert envelope(service,'recall_memory')['data']['total_saved']==1
    for i in range(8):
        assert envelope(service,'remember_memory',{**memory_args,'key':f'pin.{i}','pinned':True})['ok']
    e=envelope(service,'remember_memory',{**memory_args,'key':'pin.9','pinned':True})
    assert e['error']['code']=='pin_limit'
    page=envelope(service,'recall_memory',{'limit':3,'pinned_only':True})['data']
    assert page['next_offset']==3
    assert len(envelope(service,'bootstrap_elaina')['data']['conversation_memory']['memories'])>=8

def test_concurrent_memory_idempotence(service,memory_args):
    with ThreadPoolExecutor(max_workers=6) as pool:
        results=list(pool.map(lambda _:envelope(service,'remember_memory',memory_args),range(10)))
    assert all(x['ok'] for x in results)
    assert sum(x['data']['created'] for x in results)==1
    assert len({x['data']['memory']['id'] for x in results})==1

@pytest.mark.parametrize('mode',['summary','raw','combined'])
def test_original_python_cli_and_sql(service,settings,mode):
    before=hashlib.sha256(service.canon.db.read_bytes()).hexdigest()
    e=envelope(service,'search_canon',{'query':'青钥匙','mode':mode})
    assert e['ok'],e
    rows=e['data']['results']; assert rows
    assert all('document_id' in r for r in rows)
    raw=envelope(service,'search_original',{'query':'钟楼','source_path':RAW_PATH})
    assert raw['ok'] and len(raw['data']['results'])==1
    evidence=envelope(service,'read_evidence',{'document_id':2,'max_chars':20})
    assert evidence['data']['content']==RAW_TEXT[:20]
    assert evidence['data']['truncated']
    assert hashlib.sha256(service.canon.db.read_bytes()).hexdigest()==before
    with service.canon.connect() as conn:
        with pytest.raises(sqlite3.OperationalError):
            conn.execute('DELETE FROM documents')

def test_fallback_no_result_not_absence(service):
    e=envelope(service,'search_canon',{'query':'钟楼','fallback_raw':True})
    assert e['ok'] and e['data']['results'][0]['doc_type']=='raw'
    empty=envelope(service,'search_canon',{'query':'--root=unrelated-nonexistent'})
    assert empty['ok'],empty
    assert empty['data']['epistemic_status']=='unresolved'
    assert not empty['data']['absence_proven']

def test_character_offsets_and_quotas(service):
    e=envelope(service,'read_canon_excerpt',{'path':RAW_PATH,'start_offset':2,'length':7})
    assert e['ok'] and e['data']['excerpt']==RAW_TEXT[2:9]
    assert e['data']['next_offset']==9
    assert not envelope(service,'read_canon_excerpt',{'path':RAW_PATH,'length':4001})['ok']
    assert not envelope(service,'read_canon_excerpt',{'path':RAW_PATH,'start_offset':99999})['ok']

@pytest.mark.parametrize('path',['/etc/passwd','../../etc/passwd','小说/../../SKILL.md','SKILL.md','小说\\x.txt','小说/../memory/index.sqlite3'])
def test_blocked_paths(service,path):
    assert not envelope(service,'read_canon_excerpt',{'path':path})['ok']

def test_symlink_and_changed_script_blocked(service,settings,tmp_path):
    secret=tmp_path/'private.txt'; secret.write_text('do not expose')
    (settings.skill_root/'小说/leak.txt').symlink_to(secret)
    assert not envelope(service,'read_canon_excerpt',{'path':'小说/leak.txt'})['ok']
    service.canon.script.write_text('print("unreviewed")')
    e=envelope(service,'search_canon',{'query':'青色'})
    assert e['error']['code']=='unreviewed_retriever'

@pytest.mark.parametrize('name,args',[
 ('bootstrap_elaina',{}),('get_persona_document',{'document':'not_a_document'}),
 ('read_evidence',{'document_id':999}),('recall_memory',{}),('unknown',{}),
])
def test_continuity_on_success_and_business_failure(service,name,args):
    e=envelope(service,name,args)
    assert e['continuity']['persona_name']=='伊蕾娜'
    assert '下一条可见文字' in e['continuity']['reminder']

def test_readonly_config_hides_mutations(settings):
    s=Service(replace(settings,enable_writes=False))
    assert len(s.tools)==8
    assert not {'remember_memory','update_memory','forget_memory'} & set(s.tools)
    assert all(t.definition()['annotations']['readOnlyHint'] for t in s.tools.values())

def test_write_annotations(service):
    for n in ['remember_memory','update_memory','forget_memory']:
        assert not service.tools[n].definition()['annotations']['readOnlyHint']
    assert service.tools['forget_memory'].definition()['annotations']['destructiveHint']

@pytest.mark.parametrize('changes',[
 {'host':'0.0.0.0'}, {'auth_mode':'none'}, {'port':0}, {'allowed_origins':('*',)},
 {'auth_mode':'oauth'}, {'requests_per_minute':0},
])
def test_unsafe_config_rejected(settings,changes):
    with pytest.raises(ValueError): replace(settings,**changes).validate()

def test_memory_cannot_be_inside_canon(settings):
    with pytest.raises(ValueError): replace(settings,data_dir=settings.skill_root/'data').validate()

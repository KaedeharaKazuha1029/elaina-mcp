#!/usr/bin/env python3
"""Local/remote MCP probe. Read-only by default; --write-test adds and deletes one test record."""
from __future__ import annotations
import argparse
import json
import os
import sys
import uuid
import urllib.request
from urllib.parse import urlsplit

class Probe:
    def __init__(self,url,token):
        self.url,self.token,self.counter,self.version=url,token,0,'2025-11-25'
    def call(self,method,params):
        self.counter+=1
        data=json.dumps({'jsonrpc':'2.0','id':self.counter,'method':method,'params':params},ensure_ascii=False).encode()
        headers={'Content-Type':'application/json','Accept':'application/json, text/event-stream','MCP-Protocol-Version':self.version}
        if self.token: headers['Authorization']='Bearer '+self.token
        r=urllib.request.Request(self.url,data=data,headers=headers,method='POST')
        # No redirect following: never forward a bearer token to another endpoint.
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self,req,fp,code,msg,headers,newurl): return None
        with urllib.request.build_opener(NoRedirect()).open(r,timeout=40) as response:
            out=json.loads(response.read())
        if 'error' in out: raise RuntimeError(f'RPC failed: {out["error"].get("code")}')
        return out['result']
    def tool(self,name,arguments):
        result=self.call('tools/call',{'name':name,'arguments':arguments})
        out=result.get('structuredContent')
        if out is None: out=json.loads(result['content'][0]['text'])
        if not out.get('ok'): raise RuntimeError(f'Tool {name} failed: {out.get("error",{}).get("code")}')
        return out['data']

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--url',default='http://127.0.0.1:8000/mcp')
    p.add_argument('--write-test',action='store_true',help='Explicitly authorize adding and then deleting one synthetic test memory')
    args=p.parse_args()
    u=urlsplit(args.url)
    if u.username or u.password or u.fragment or u.query: p.error('Use a clean endpoint URL; tokens go in ELAINA_ACCESS_TOKEN')
    if u.scheme!='https' and not (u.scheme=='http' and u.hostname in ('127.0.0.1','localhost','::1')):
        p.error('Remote probes require HTTPS')
    probe=Probe(args.url,os.getenv('ELAINA_ACCESS_TOKEN',''))
    init=probe.call('initialize',{'protocolVersion':probe.version,'capabilities':{},'clientInfo':{'name':'elaina-smoke-test','version':'1.0'}})
    probe.version=init['protocolVersion']
    if probe.version not in ('2025-03-26','2025-06-18','2025-11-25'): raise RuntimeError('Unsupported negotiated protocol')
    tools=probe.call('tools/list',{})['tools']
    bootstrap=probe.tool('bootstrap_elaina',{})
    status=probe.tool('elaina_status',{})
    report={'protocol':probe.version,'tools':len(tools),'persona_loaded':bootstrap['initialization_complete'],
            'canon_ready':status['canon']['ready'],'full_manifest_validated':status['canon']['full_manifest_validated'],
            'memory_writes_enabled':status['memory']['writes_enabled'],'chatgpt_ui_verified':False}
    if args.write_test:
        if not any(t['name']=='remember_memory' for t in tools): raise RuntimeError('Write tools are not enabled')
        unique='smoke.'+uuid.uuid4().hex
        saved=probe.tool('remember_memory',{'key':unique,'content':'Synthetic deployment smoke-test record. Not a user preference.',
            'category':'interaction','source_quote':'Operator explicitly ran smoke_test.py --write-test','consent':'user_requested'})['memory']
        try:
            recalled=probe.tool('recall_memory',{'query':unique})
            if not any(m['id']==saved['id'] for m in recalled['memories']): raise RuntimeError('Read-after-write verification failed')
            report['write_read_test']='passed'
        finally:
            deleted=probe.tool('forget_memory',{'memory_id':saved['id'],'expected_version':saved['version'],
                'source_quote':'Operator authorized cleanup via --write-test','consent':'user_requested'})
            report['test_memory_deleted']=deleted['deleted'] or deleted['already_absent']
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':
    try: main()
    except Exception as exc:
        # HTTP error bodies and access tokens are intentionally not printed.
        print(f'Probe failed ({type(exc).__name__}); check endpoint, authorization, and server logs.',file=sys.stderr)
        raise SystemExit(1)

#!/usr/bin/env python3
"""Export host rules plus the original persona documents, without editing the skill."""
from __future__ import annotations
import argparse
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from elaina_mcp.persona import Persona

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--skill-root',type=Path,required=True)
    p.add_argument('--output',type=Path,default=Path('prompts/CHATGPT_FULL_PROMPT.md'))
    args=p.parse_args()
    if args.output.resolve().is_relative_to(args.skill_root.resolve()):
        p.error('Output must be outside the original skill repository')
    text=Persona(args.skill_root).export_prompt()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(text,encoding='utf-8')
    print(f'Exported {len(text)} characters to {args.output}')

if __name__=='__main__': main()

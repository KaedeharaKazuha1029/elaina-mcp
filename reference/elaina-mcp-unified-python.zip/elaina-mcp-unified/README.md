# Elaina MCP Unified · 人格、原作与持久记忆

基于 `KaedeharaKazuha1029/elaina-skill` 的私有 MCP 合并适配器。以原 skill 人格文件为来源，合并原作摘要检索、Python 原文检索、SQLite 证据读取和文件片段读取，并新增独立的对话记忆数据库。

**交付的是可运行源代码、提示词、测试和部署配置；不是已经上线的服务，也不是上传 ZIP 就能自动安装到 ChatGPT 的插件。** 原 GitHub 仓库未被修改。原作语料需要另行放在服务运行机器上，本包不包含完整小说和原作 SQLite 数据库。

## 先看这三个事实

**人格连续性不等于工具调用。** 首次加载后，第一句、工具调用前说明、失败、普通闲聊都要求保持伊蕾娜；不能等 MCP 返回才切换。短身份规则应放在宿主持续提供的指令位置。只把规则写在 MCP 返回值里，无法控制已经发出的前置回复。

**数据库持久化不等于模型永远自动记得。** 记忆在本服务数据库中持久保存，但模型需要调用 `recall_memory` 或 `bootstrap_elaina` 取回。不会读取 ChatGPT 全部历史，不会自动与 ChatGPT 原生记忆同步，不会在用户没授权时把聊天全部存下来。

**MCP 服务端无法替代宿主的执行权限。** 当前 OpenAI 官方说明将完整自定义 MCP 写入能力与只读能力区分；实际能否从你的账户执行记忆写操作，需要看账户、工作区和工具权限。禁止把写操作伪装成只读。[官方说明](https://help.openai.com/en/articles/12584461-developer-mode-and-mcp-apps-in-chatgpt)

## 1. 相比两个旧包，合并了什么

| 来源/新增 | 合并后实现 |
|---|---|
| Addon 的人格文档 | 完整读取 SOUL、IDENTITY、PERSONA_ELAINA、RUNTIME_GUARD，不以通用傲娇模板替换 |
| Addon 的统一检索 | 保留 summary / raw / combined / fallback 与路径过滤 |
| Addon 的文件片段 | 限定语料目录、Unicode 字符分页，不读取任意文件 |
| Bridge 的数据库证据 | 返回检索结果的 document_id，按 ID 只读查询证据 |
| Bridge 的远程传输方式 | 无状态 Streamable HTTP，JSON 响应，另有 stdio |
| 新增人格连续性 | 宿主短指令、完整人格提示词、bootstrap、工具描述、返回值提醒 |
| 新增持久记忆 | 授权新增、检索、修正、删除，独立 SQLite、稳定 key、防静默覆盖 |
| 新增访问边界 | 本地回环限制；远程 OAuth JWT 校验、单一 owner、读写 scope 区分 |

上游核对版本：`b940fe08dec019807644f5bf5497d6299cf77ef6`。`upstream.lock.json` 记录六份保留原件的哈希。原检索脚本必须匹配核对过的 Git blob；上游更新后需审查再修改锁定值，不能悄悄执行另一版 Python。

## 2. 目录和数据流

```text
工作目录/
├── elaina-skill/                 # 原仓库，只读；独立取得
│   ├── assets/openclaw-workspace/
│   ├── 小说/
│   ├── 文章概括/
│   ├── memory/index.sqlite3
│   └── scripts/retrieve_memory.py
└── elaina-mcp-unified/
    ├── server.py                # HTTP / stdio 启动入口
    ├── elaina_mcp/              # 人格、检索、记忆、认证、MCP 协议
    ├── prompts/                # 短指令、宿主规则、完整人格提示词
    ├── scripts/                # 导出提示词、连接自检
    ├── tests/                  # 合成语料测试；不是完整小说
    ├── docs/                   # 部署边界、验收、实际测试报告
    └── data/                   # 运行后创建，不随本包分发
        └── conversations.sqlite3
```

聊天 → 宿主常驻身份规则 → 模型决定调用工具 → MCP 读取人格/原作或已批准的对话记忆 → 仍以原身份回答。MCP 不能插入 ChatGPT 真正的系统提示词，也不能拦截或改写客户端的前置输出。

服务只执行已锁定的 `retrieve_memory.py`，不提供 `exec`、任意 Python、Shell 或任意 SQL 工具。原数据库使用只读连接，用户对话库与原仓库必须位于不同目录。

## 3. 本地运行：先确认服务本身可用

要求 Python 3.11+；本次实际验证环境是 Python 3.13。部署需要自行安装 `requirements.txt` 依赖。以下命令在有网络的自己的机器上执行。

### 准备原 skill

在新目录中克隆，不覆盖你正在开发的原仓库：

```bash
git -c core.autocrlf=false clone https://github.com/KaedeharaKazuha1029/elaina-skill.git ../elaina-skill
git -C ../elaina-skill checkout --detach b940fe08dec019807644f5bf5497d6299cf77ef6
```

保留 LF 换行；Windows 自动转成 CRLF 会导致原 Python 的字节哈希不一致。已有同名目录时不要盲目运行覆盖/重置命令；改用另一目录并调整 `ELAINA_SKILL_ROOT`。

### Linux / macOS

在解压后的 `elaina-mcp-unified` 目录中：

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
export ELAINA_SKILL_ROOT="$(cd ../elaina-skill && pwd)"
export ELAINA_DATA_DIR="$PWD/data"
export ELAINA_AUTH_MODE=local
export ELAINA_HOST=127.0.0.1
python server.py
```

### Windows PowerShell

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
$env:ELAINA_SKILL_ROOT = (Resolve-Path ..\elaina-skill).Path
$env:ELAINA_DATA_DIR = Join-Path $PWD.Path 'data'
$env:ELAINA_AUTH_MODE = 'local'
$env:ELAINA_HOST = '127.0.0.1'
.\.venv\Scripts\python.exe server.py
```

另开终端，使用同一 Python 环境执行：

```bash
python scripts/smoke_test.py --url http://127.0.0.1:8000/mcp
```

默认只读。`--write-test` 表示操作者明确授权创建一条合成测试记忆并随后删除：

```bash
python scripts/smoke_test.py --url http://127.0.0.1:8000/mcp --write-test
```

`/healthz` 只证明服务进程在响应；`elaina_status` 检查人格/索引存在性与文档数量；两者都不替代原仓库的完整语料校验。测试语料只在 pytest 临时目录创建，正式运行不要把 `tests/fixtures/upstream` 当成小说库。

通用本地 MCP 客户端可参照 `mcp.local.example.json` 配置 `--transport stdio`，所有路径应改为绝对路径。**该 JSON 是通用 stdio 示例，不是 ChatGPT 网页端安装文件。**

## 4. 你要求的“调用前也不出戏”：怎么配置

### 常驻短指令

`prompts/CHATGPT_CUSTOM_INSTRUCTIONS.txt` 是短版身份规则。把其内容放到你的 ChatGPT 自定义指令，或你使用的支持常驻指令的宿主位置。应先确认该位置确实适用于目标对话；不是仅上传一个 txt 附件。

它明确写了：本指令的适用范围内默认启用伊蕾娜；不需要每轮提名字；除首次初始化外，后续所有可见输出先继承身份再决定用工具；不把连接失败、恢复上下文或新对话视为出戏许可。用户明确退出时停止角色风格。

### 完整人格

`prompts/CHATGPT_FULL_PROMPT.md` 包含宿主适配规则和四份原人格文档全文。可用于有足够指令空间的宿主；空间受限时使用短版，完整人格由首次 `bootstrap_elaina` 返回。两份指令是同一套要求的不同长度版本，不必无意义重复粘贴。

部署自己的原 skill 后可重新导出：

```bash
python scripts/export_chatgpt_prompt.py --skill-root ../elaina-skill --output prompts/CHATGPT_FULL_PROMPT.md
```

初始化时对目标宿主说：

> 启用这个 Elaina MCP，先调用 bootstrap_elaina 加载完整人格与已授权记忆。首次加载后，包含下一轮调用任何工具前的第一句话，都继续以伊蕾娜身份交流，不要先变回普通助手再切换。

### 四层配合，不伪装为强制钩子

| 层 | 作用 | 做不到的事 |
|---|---|---|
| 宿主常驻短指令 | 工具返回前就有身份要求 | 不能覆盖平台系统规则或保证模型零失误 |
| bootstrap | 完整人格原文 + 检索政策 + 已存相关记忆 | 不等于修改 ChatGPT 系统提示词 |
| 工具说明与 MCP initialize.instructions | 工具可见时补充身份连续性约束 | 客户端可能不加载或不采纳 |
| 每次工具结果 continuity | 成功和业务错误都提醒后续输出 | 网络未连上、认证拒绝、协议错误时没有工具结果 |

第一句可能早于工具调用，因此不能仅依赖最后一层。跨对话要靠仍适用的宿主指令和实际记忆查询；服务重启不会删除数据库，但没有工具权限时模型拿不到其中的事实。原 skill 的 OpenClaw Project Context 自动注入机制没有在 ChatGPT 内被复制或伪造。

## 5. 工具一览

| 工具 | 类型 | 用法 |
|---|---|---|
| `bootstrap_elaina` | 读 | 首次初始化、完整人格丢失时恢复；不每轮重载 |
| `get_persona_document` | 读 | 白名单人格/政策文档，字符分页 |
| `recall_memory` | 读 | 查询已批准记忆；空 query 按新近顺序列出，offset 翻页 |
| `remember_memory` | 写 | 用户明确批准后保存，稳定 key 防重复 |
| `update_memory` | 修改 | memory_id + expected_version，冲突拒绝覆盖 |
| `forget_memory` | 删除 | memory_id + expected_version，删除指定记录 |
| `search_canon` | 读 | 摘要优先，可 raw/combined/fallback |
| `search_original` | 读 | 原文检索，可按 source_path 过滤 |
| `read_evidence` | 读 | document_id → SQLite 原文/摘要证据 |
| `read_canon_excerpt` | 读 | 语料路径 + 字符偏移，最多 4000 字符 |
| `elaina_status` | 读 | 人格版本、索引状态、当前能力 |

没有 `user_id` 参数：远程服务绑定一个经认证的 owner，模型不能用随意传入的用户名切换别人的记忆。

设置 `ELAINA_ENABLE_WRITES=false` 后，三个写工具不再出现在工具列表，只剩 8 个读工具。改变后应刷新宿主保存的工具定义，不能假定 ChatGPT 自动同步。

## 6. 记忆机制与授权

对话记忆分为 preference、fact、project、interaction、roleplay。每条保存内容、来源授权原话、类别、标签、时间、版本；不存完整聊天历史。`source_quote` 必须来自用户真实授权，但服务仅能检查字段与类型，**不能独立证明模型提供的这句话确实是用户说的**；仍需宿主确认和操作者权限保护。

首次保存示例：

```json
{
  "key": "preferred_reply_language",
  "content": "用户希望默认用中文交流。",
  "category": "preference",
  "source_quote": "请记住：以后默认用中文和我交流。",
  "consent": "user_requested",
  "tags": ["交流偏好"],
  "pinned": true
}
```

相同 key、相同正文可安全重试；同 key 不同正文返回冲突。修正必须先查询 ID/version，再执行 update。最多 8 条置顶、10000 条记录；启动返回置顶、相关和近期记录的有限集合，不假装把所有记忆塞进上下文。搜索是支持中文二元词片段的确定性文本匹配，不是向量语义检索。

删除会移除本服务活动数据库中的记录；不删除 ChatGPT 聊天记录、云备份、文件系统快照或原作资料。数据库不是默认加密数据库；应使用受控磁盘、账号权限、磁盘加密及加密备份。运行中备份应使用 SQLite 备份 API，或停止服务后一起备份正确的数据库状态，不只复制可能遗漏 WAL 的单个文件。

本地模式的 owner 是 `local-owner`，OAuth 模式是配置的 `ELAINA_OWNER_SUB`。切换 owner 后旧记录不会自动成为新 owner 的记录；这是一条隔离边界，不是数据丢失。确需迁移时先备份、确认归属后做受控离线迁移，不由模型改 namespace。

## 7. 远程部署与 ChatGPT 接入

详见 `docs/REMOTE_DEPLOYMENT.md`。本地启动成功不等于 ChatGPT 已连接：需要可达的 MCP 服务、认证、宿主入口和对应权限。官方还提供适用于受支持场景的 Secure MCP Tunnel；本包没有代你建立隧道。[官方接入说明](https://help.openai.com/en/articles/12584461-developer-mode-and-mcp-apps-in-chatgpt)

本包提供 Docker、Compose、Caddy 示例，但未在本次环境中构建 Docker 镜像、签发证书或接入真实 OAuth 提供商。所有 example 占位符必须替换；不要直接公网暴露 local 无认证模式，不能将私有记忆变成公开读取接口。

## 8. 测试与实现边界

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
```

实际结果见 `docs/TEST_REPORT.md`、`docs/verification.log` 与 JUnit XML。

测试执行真实上游 Python 脚本、真实 SQLite、ASGI HTTP 测试和本地 Uvicorn/stdio 子进程；小说内容是合成数据。本次没有下载和验证完整原作数据库，也没有通过 ChatGPT UI 连接验证，更没有证明模型在每一种前置回复中都能百分之百保持角色。

MCP 传输层是本包自带的受限 JSON-RPC 实现，不是偷偷调用未安装的 FastMCP，也不是官方 SDK 的完整复刻。实现版本基线 2025-03-26 / 2025-06-18 / 2025-11-25；支持 tools、prompts、resources、版本协商、无状态 JSON HTTP 与 stdio。旧版 batch 限 16 条，新版拒绝 batch；不提供 SSE 推送、sampling、elicitation、tasks、取消正在执行的检索或 2024 HTTP+SSE。只声明已实现的能力，尚无 MCP Inspector/官方 SDK 的互操作认证结论。

## 9. 授权与来源

许可证及署名见 `LICENSE`、`NOTICE.md`。原件保留、协议依据和合并范围详见 `docs/SOURCES.md`、`docs/INTEGRATION_MAP.md`。依赖锁定为本次实际验证版本；更新依赖、协议或上游脚本后需要重新审查和测试。
